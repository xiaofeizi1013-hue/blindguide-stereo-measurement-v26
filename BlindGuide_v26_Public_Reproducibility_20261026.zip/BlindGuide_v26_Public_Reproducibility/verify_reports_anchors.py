"""Independent checks of reported errors, anchor populations and fixed-MAD scans."""
from pathlib import Path
import hashlib,json
import numpy as np
import pandas as pd
R=Path(__file__).resolve().parent; A=R/'analysis'
f=pd.read_csv(A/'backend_features.csv')
p=pd.read_csv(A/'backend_predictions.csv')
r=pd.read_csv(A/'reported_backend_metrics.csv')
scan=pd.read_csv(A/'mad_threshold_scan.csv')
keys=['backend','session','protocol']
by=f.set_index(['backend','session','seq'])

def check(g,row,theta=3.):
    q=by.loc[pd.MultiIndex.from_frame(g[['backend','session','seq']])]
    pred=g.K.to_numpy()/(q.d.to_numpy()-g.d0.to_numpy())
    truth=g.true_m.to_numpy()*1000
    valid=np.isfinite(pred)&(pred>0)&(g.K.to_numpy()>0)&q.computable.to_numpy()
    report=valid&(q.mad.to_numpy()<=theta)&(q.n.to_numpy()>=10)
    err=np.abs(pred-truth)
    assert len(g)==row.attempted_n
    for label,mask in [('valid_',valid),('reported_',report)]:
        assert mask.sum()==row[label+'n']
        if mask.any():
            vals={'MAPE':100*np.mean(err[mask]/truth[mask]),'MAE_mm':np.mean(err[mask]),
                  'p95_mm':np.quantile(err[mask],.95),'max_mm':np.max(err[mask])}
            for name,value in vals.items():
                assert np.isclose(value,row[label+name],rtol=1e-10,atol=1e-7),(label,name,value,row[label+name])
        else:
            assert all(pd.isna(row[label+x]) for x in ['MAPE','MAE_mm','p95_mm','max_mm'])
    for t in [250,500,1000]:
        large=valid&(err>t)
        assert large.sum()==row[f'valid_gt{t}_n']
        passed=int((large&report).sum())
        assert passed==row[f'reported_gt{t}_n']
        for denom,col in [(int(large.sum()),f'pass_given_gt{t}_pct'),(int(report.sum()),f'gt{t}_given_report_pct')]:
            if denom: assert np.isclose(passed/denom*100,row[col])
            else: assert pd.isna(row[col])
    if theta==3:
        assert np.array_equal(report,g.gate_accept.to_numpy())
    return report

groups={k:g for k,g in p.groupby(keys,sort=False)}
for _,row in r.iterrows(): check(groups[tuple(row[k] for k in keys)],row)
for _,row in scan.iterrows(): check(groups[tuple(row[k] for k in keys)],row,row.threshold_px)
distance=pd.read_csv(A/'reported_backend_per_distance.csv')
for _,row in distance.iterrows():
    g=groups[tuple(row[k] for k in keys)]
    check(g[g.true_m==row.distance_m],row)

anchors=pd.read_csv(A/'anchor_disparity_summary.csv')
for _,row in anchors.iterrows():
    g=f[(f.backend==row.backend)&(f.session==row.session)&(f.true_m==row.anchor_m)]
    assert len(g)==30 and g.computable.all()
    for col,quantile in [('d_min',0),('d_p25',.25),('d_median',.5),('d_p75',.75),('d_max',1)]:
        assert np.isclose(np.quantile(g.d,quantile),row[col])
    assert np.isclose(g.mad.median(),row.frame_MAD_median)
    assert ((g.mad<=3)&(g.n>=10)).sum()==row.score_pass_n
s=f[(f.backend=='OpenCV_SGBM')&f.session.str.startswith('S1_')]
one=s[s.true_m==1.];four=s[s.true_m==4.]
assert len(one[one.d<3])==15 and len(one[one.d>40])==15
assert np.median(one.d)==22.5625 and not (one.d==22.5625).any()
k=(np.median(one.d)-np.median(four.d))/(1/1000-1/4000)
assert k==17750 and np.isclose(np.median(one.d)-k/1000,4.8125)
assert f.computable.all() and f.n.min()==389 and not (f.n<10).any()
q=pd.read_csv(A/'anchor_correspondence_checks.csv')
assert len(q)==60 and not q.seq.duplicated().any()
source=f[(f.backend=='libSGM')&f.session.str.startswith('S1_')].set_index('seq')
for _,row in q.iterrows(): assert row.frame_sha256==source.loc[row.seq].frame_sha256
assert int(q[q.true_m==1].sift_n.sum())==263
assert int((q[q.true_m==1].sift_n>0).sum())==29
assert int((q[q.true_m==1].marker_n>0).sum())==20
assert int(q[q.true_m==4].sift_n.sum())==2 and q[q.true_m==4].marker_n.sum()==0
local=pd.read_csv(A/'C1_refit_local_changes.csv')
assert local[local.delta_percentage_points>0].distance_m.tolist()==[1.5,2.,2.5]
old=R.parent/'v23_revision_20261024'
baseline=json.loads((R/'audit/v23_derived_input_hashes.json').read_text(encoding='utf8'))
unchanged=[]
for name in ['backend_features.csv','backend_predictions.csv','backend_metrics.csv','tail_metrics.csv','reset_metrics.csv','reset_per_distance.csv']:
    actual=hashlib.sha256((A/name).read_bytes()).hexdigest()
    assert actual==baseline[name]
    if old.exists(): assert actual==hashlib.sha256((old/'analysis'/name).read_bytes()).hexdigest()
    unchanged.append(name)
out=dict(status='passed',reported_protocol_rows=len(r),per_distance_rows=len(distance),threshold_rows=len(scan),
    anchor_distribution_rows=len(anchors),source_anchor_pairs=len(q),unchanged_derived_inputs=unchanged,
    scope='Recomputes outputs from preserved feature/prediction inputs; image diagnostics remain correspondence checks, not traceable distance references.')
(A/'reported_anchor_numeric_verification.json').write_text(json.dumps(out,indent=2),encoding='utf8')
print(json.dumps(out,indent=2))
