"""Recompute reset protocol and per-distance rows using packaged source CSVs."""
from pathlib import Path
import json,hashlib
import numpy as np,pandas as pd
R=Path(__file__).resolve().parent;A=R/'analysis';S=A/'reset_sources'
C0=S/'C0_CAL_20261024_2144';C1=S/'C1_RESET_20261024_2153'
x0=pd.read_csv(C0/'C0_board_features.csv');x1=pd.read_csv(C1/'C1_board_features.csv')
f=json.loads((C0/'freeze_c0.json').read_text(encoding='utf8'))
assert hashlib.sha256((C0/'C0_board_features.csv').read_bytes()).hexdigest()==f['features_sha256']
assert hashlib.sha256((C0/'C0_board_boxes.json').read_bytes()).hexdigest()==f['boxes_sha256']
def fit(g):
 a=g.groupby('true_m').d.median();k=(a[1.]-a[4.])/(.001-.00025);return float(k),float(a[1.]-k*.001)
k0,d0=fit(x0);k1,d1=fit(x1)
assert np.isclose(k0,f['K_mm_px']) and np.isclose(d0,f['d0_px'])
def metrics(g,k,b):
 z=g.true_m.to_numpy()*1000.;pred=k/(g.d.to_numpy()-b)
 c=np.isfinite(g.d.to_numpy())&(g.n.to_numpy()>=30)&(g.valid_fraction.to_numpy()>=.25)
 valid=c&np.isfinite(pred)&(pred>0)&(k>0);report=valid&(g.mad.to_numpy()<=3)&(g.n.to_numpy()>=10)
 err=pred-z;ae=abs(err);v=ae[valid]
 out=dict(n_attempted=len(g),n_computable=int(c.sum()),n_valid=int(valid.sum()),n_reported=int(report.sum()),
   coverage_pct=float(report.mean()*100),K_mm_px=k,d0_px=b,MAPE=float((v/z[valid]*100).mean()),
   MAE_mm=float(v.mean()),bias_mm=float(err[valid].mean()),p95_mm=float(np.percentile(v,95)),max_mm=float(v.max()))
 for t in [250,500,1000]:
  bad=valid&(ae>t);out[f'gt_{t}mm_n']=int(bad.sum());out[f'gt_{t}mm_reported_n']=int((bad&report).sum())
 bad=valid&(ae/z>.2);out['gt_20pct_n']=int(bad.sum());out['gt_20pct_reported_n']=int((bad&report).sum())
 return out
def check(row,out):
 for k,v in out.items():assert np.isclose(row[k],v,atol=1e-8,rtol=1e-9),(k,row[k],v)
expected=pd.read_csv(A/'reset_metrics.csv').set_index('label')
cases=[('C0 calibration anchors 60',x0,k0,d0),('C1 frozen C0 all10 300',x1,k0,d0),
 ('C1 frozen C0 common8 240',x1[~x1.true_m.isin([1.,4.])],k0,d0),
 ('C1 refit all10 300 including anchors',x1,k1,d1),
 ('C1 refit heldout8 240',x1[~x1.true_m.isin([1.,4.])],k1,d1)]
for label,g,k,b in cases:check(expected.loc[label],metrics(g,k,b))
per=pd.read_csv(A/'reset_per_distance.csv')
for protocol,k,b in [('frozen_C0',k0,d0),('refit_C1',k1,d1)]:
 for z,g in x1.groupby('true_m'):
  row=per[(per.protocol==protocol)&(per.distance_m==z)].iloc[0];check(row,metrics(g,k,b))
replay=pd.read_csv(A/'reset_replayed_features.csv');max_differences={}
for source in [x0,x1]:
 rr=replay[replay.session==source.session.iloc[0]].sort_values('seq');ss=source.sort_values('seq')
 assert rr.seq.tolist()==ss.seq.tolist()
 for key in ['d','d_untrim','mad','n','area','valid_fraction','n_trim','p10','p90']:
  diff=float(np.max(abs(rr[key].to_numpy()-ss[key].to_numpy())))
  max_differences[key]=max(max_differences.get(key,0.),diff)
  assert np.allclose(rr[key],ss[key],atol=1e-9,rtol=0),key
out=dict(status='passed',reset_protocol_rows=5,reset_per_distance_rows=20,source_frames=360,
 C1_frozen_n=300,C1_refit_heldout_n=240,K_effective_change_pct=(k1/k0-1)*100,
 replay_max_differences=max_differences,
 scope='Arithmetic and image-replay cache checked; reset operation and missing reference metadata retain their stated evidence scope.')
(A/'reset_numeric_verification.json').write_text(json.dumps(out,indent=2),encoding='utf8')
print(json.dumps(out,indent=2))
