"""Draw the direct-image figures entirely from the packaged evidence caches."""
from pathlib import Path
import json
import numpy as np,pandas as pd,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
R=Path(__file__).resolve().parent;E=R/'representatives';F=R/'figures';F.mkdir(exist_ok=True)
cases={x['case']:x for x in json.loads((E/'cases_manifest.json').read_text(encoding='utf8'))}
sift=pd.read_csv(E/'sift_correspondences.csv');marks=pd.read_csv(E/'marker_correspondences.csv')
plt.rcParams.update({'font.size':11,'axes.titlesize':12,'axes.labelsize':10,'legend.fontsize':9,'savefig.dpi':210,'font.family':'DejaVu Sans'})
def load(tag):return dict(np.load(E/(tag+'.npz')))
def save(fig,name):
    fig.savefig(F/(name+'.png'),bbox_inches='tight',pad_inches=.08)
    fig.savefig(F/(name+'.svg'),bbox_inches='tight',pad_inches=.08)
    plt.close(fig)
def extent(z):
    x,y=z['crop_origin'];h,w=z['left'].shape;return [x,x+w,y+h,y]
def contour(ax,z,m,color,style='solid',width=1.4):
    x,y=z['crop_origin'];ax.contour(np.arange(m.shape[1])+x,np.arange(m.shape[0])+y,m>0,levels=[.5],colors=[color],linestyles=[style],linewidths=[width])
def image(ax,z,key='left'):
    ax.imshow(z[key],cmap='gray',vmin=0,vmax=255,extent=extent(z));ax.set_xlabel('Working x (px)');ax.set_ylabel('Working y (px)')
def tight(ax,z,pad=8):
    yy,xx=np.where(z['mask']>0);x,y=z['crop_origin'];ax.set_xlim(x+xx.min()-pad,x+xx.max()+pad);ax.set_ylim(y+yy.max()+pad,y+yy.min()-pad)

z=load('S1_regions_105');fig,axes=plt.subplots(1,2,figsize=(6.6,4.7))
fig.subplots_adjust(left=.10,right=.98,bottom=.23,top=.91,wspace=.12)
for ax,key in zip(axes,['raw_left','left']):image(ax,z,key)
contour(axes[0],z,z['person_direct'],'#cc3377');contour(axes[0],z,z['board_direct'],'#e69f00')
axes[0].set_title('(a) Archived raw ROI geometry')
for name,color in [('person','#cc3377'),('board','#e69f00')]:
    contour(axes[1],z,z[name+'_direct'],color)
    contour(axes[1],z,z[name+'_mapped'],color,'dashed')
axes[1].set_title('(b) Rectified ROI geometry')
fig.legend([Line2D([],[],color='#cc3377'),Line2D([],[],color='#e69f00'),Line2D([],[],color='black'),Line2D([],[],color='black',ls='--')],
    ['Person core','Board core','Direct coordinates','Remapped mask'],loc='lower center',ncol=2,frameon=False,fontsize=10)
for ax in axes:
    yy,xx=np.where((z['person_direct']>0)|(z['board_direct']>0)|(z['person_mapped']>0)|(z['board_mapped']>0))
    x,y=z['crop_origin'];ax.set_xlim(x+xx.min()-14,x+xx.max()+14);ax.set_ylim(y+yy.max()+14,y+yy.min()-14)
save(fig,'fig1')

def correspondence(ax,tag,with_markers=False):
    z=load(tag);a=sift[(sift.case==tag)&sift.retained];b=marks[(marks.case==tag)&marks.retained] if with_markers else marks.iloc[:0]
    yy,xx=np.where(z['mask']>0);x0,y0=map(int,z['crop_origin'])
    shift=float(np.median(a.disparity_px)) if len(a) else 0
    lx1=max(0,int(xx.min())-15);lx2=min(z['left'].shape[1],int(xx.max())+16)
    yy1=max(0,int(yy.min())-15);yy2=min(z['left'].shape[0],int(yy.max())+16)
    rx1=max(0,int(round(lx1-shift)));rx2=min(z['right'].shape[1],int(round(lx2-shift)))
    left=z['left'][yy1:yy2,lx1:lx2];right=z['right'][yy1:yy2,rx1:rx2]
    gap=12;canvas=np.full((left.shape[0],left.shape[1]+right.shape[1]+gap),255,np.uint8)
    canvas[:,:left.shape[1]]=left;canvas[:,left.shape[1]+gap:]=right
    ax.imshow(canvas,cmap='gray',vmin=0,vmax=255)
    for frame,col,label in [(a,'#ffb000','SIFT'),(b,'#00e5ff','Marker corner')]:
        for _,m in frame.iterrows():
            u=(m.x_left-x0-lx1,m.y_left-y0-yy1);v=(m.x_right-x0-rx1+left.shape[1]+gap,m.y_right-y0-yy1)
            ax.plot([u[0],v[0]],[u[1],v[1]],color=col,lw=.7,alpha=.85)
            ax.plot([u[0],v[0]],[u[1],v[1]],'o',mec=col,mfc='none',ms=3)
            if label=='Marker corner':ax.text(u[0]+1,u[1]-2,f'{int(m.marker_id)}:{int(m.corner_index)}',color=col,fontsize=9)
    ax.text(.01,.98,'Left',transform=ax.transAxes,va='top',color='black',fontsize=9,bbox=dict(facecolor='white',edgecolor='none',alpha=.85,pad=1))
    ax.text(.63,.98,'Right',transform=ax.transAxes,va='top',color='black',fontsize=9,bbox=dict(facecolor='white',edgecolor='none',alpha=.85,pad=1))
    ax.set_xticks([]);ax.set_yticks([])
    c=cases[tag];ax.set_xlabel(f'SIFT {len(a)}/{c["sift_candidate_n"]} retained; median {shift:.3f} px'+(f'\nDecoded corners retained: {len(b)}' if with_markers else ''),fontsize=10)

def dense_panel(ax,z,backend):
    image(ax,z);data=np.ma.masked_where((z['mask']==0)|(z[backend]<=.5),z[backend])
    im=ax.imshow(data,cmap='viridis',vmin=.5,vmax=128,extent=extent(z));contour(ax,z,z['mask'],'white',width=.8)
    tight(ax,z);return im
def histogram(ax,z,tag):
    bins=np.arange(.5,128.5,.5)
    for backend,label,color in [('libSGM','libSGM','#0072b2'),('OpenCV_SGBM','OpenCV','#d55e00')]:
        vals=z[backend][(z['mask']>0)&(z[backend]>.5)];st=cases[tag]['statistics'][backend]
        ax.hist(vals,bins=bins,histtype='step',color=color,lw=1.1,label=f'{label}: {st["d"]:.3f} px')
    ax.set_xlim(.5,128);ax.set_xlabel('Pixel disparity (px)');ax.set_ylabel('Valid pixels');ax.legend(loc='upper right',fontsize=9.5)
    ax.grid(alpha=.15)

tags=['S7_failure_91','S7_next_92'];fig,axes=plt.subplots(3,2,figsize=(7.2,8.4),gridspec_kw={'height_ratios':[1.25,1,.8]},layout='constrained')
for col,tag in enumerate(tags):
    z=load(tag);st=cases[tag]['statistics']['libSGM'];im=dense_panel(axes[0,col],z,'libSGM')
    axes[0,col].set_title(f'({chr(97+col)}) S7 frame {cases[tag]["seq"]}: libSGM')
    axes[0,col].set_xlabel(f'n={st["n"]}; after trim={st["n_trim"]}\nMAD={st["mad"]:.4f} px')
    histogram(axes[1,col],z,tag);axes[1,col].set_title(f'({chr(99+col)}) Initial ROI distribution')
    correspondence(axes[2,col],tag);axes[2,col].set_title(f'({chr(101+col)}) Retained SIFT pairs')
fig.colorbar(im,ax=axes[0,:],label='Disparity (px)',shrink=.85)
save(fig,'figS3_S7_image_evidence')

tags=['S1_anchor_high_31','S1_anchor_low_32'];fig,axes=plt.subplots(3,2,figsize=(7.2,8.4),gridspec_kw={'height_ratios':[1.25,1,.8]},layout='constrained')
for col,tag in enumerate(tags):
    z=load(tag);st=cases[tag]['statistics']['OpenCV_SGBM'];im=dense_panel(axes[0,col],z,'OpenCV_SGBM')
    axes[0,col].set_title(f'({chr(97+col)}) S1 frame {cases[tag]["seq"]}: OpenCV')
    axes[0,col].set_xlabel(f'n={st["n"]}; after trim={st["n_trim"]}\nMAD={st["mad"]:.4f} px; '+('pass' if st['mad']<=3 else 'reject'))
    histogram(axes[1,col],z,tag);axes[1,col].set_title(f'({chr(99+col)}) Initial ROI distribution')
    correspondence(axes[2,col],tag,True);axes[2,col].set_title(f'({chr(101+col)}) SIFT and decoded corners')
fig.colorbar(im,ax=axes[0,:],label='Disparity (px)',shrink=.85)
save(fig,'figS4_anchor_image_evidence')

tag='S10_supported_75';z=load(tag);fig=plt.figure(figsize=(7.2,5.5),layout='constrained');grid=fig.add_gridspec(2,2,height_ratios=[1.1,.8])
axes=[fig.add_subplot(grid[0,0]),fig.add_subplot(grid[0,1]),fig.add_subplot(grid[1,:])]
image(axes[0],z);contour(axes[0],z,z['mask'],'#00e5ff');tight(axes[0],z,25);axes[0].set_title('(a) S10 frame 75 target crop')
im=dense_panel(axes[1],z,'libSGM');axes[1].set_title('(b) libSGM disparity in ROI')
correspondence(axes[2],tag);axes[2].set_title('(c) Retained SIFT correspondences')
fig.colorbar(im,ax=axes[1],label='Disparity (px)',shrink=.85)
save(fig,'figS5_S10_image_evidence')
print('Wrote main Fig. 1 and supplementary Figs. S3-S5 from shareable caches.')
