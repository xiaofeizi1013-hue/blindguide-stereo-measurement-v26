"""Hold frame IDs fixed when comparing the archived calibration protocols."""
from pathlib import Path
import json
import numpy as np,pandas as pd
R=Path(__file__).resolve().parent;A=R/'analysis'
p=pd.read_csv(A/'predictions.csv');b=pd.read_csv(A/'backend_predictions.csv')

def metric(g,error,valid,report):
    e=np.abs(np.asarray(error));z=g.true_m.to_numpy()*1000;v=np.asarray(valid,bool);r=np.asarray(report,bool)
    o=dict(attempted_n=len(g),valid_n=int(v.sum()),reported_n=int(r.sum()),coverage_pct=float(np.mean(r)*100),
        MAPE=float(np.mean(e[v]/z[v])*100),MAE_mm=float(np.mean(e[v])),p95_mm=float(np.percentile(e[v],95,method='linear')),
        max_mm=float(e[v].max()),gt500_n=int(((e>500)&v).sum()),gt500_reported_n=int(((e>500)&r).sum()))
    return o

rows=[];frames=[]
for se,g in p.groupby('session',sort=False):
    frozen=g[g.protocol=='frozen_S1'].copy();anchor=g[g.protocol=='two_anchor_heldout'].copy()
    if anchor.empty:continue
    ids=sorted(set(frozen.seq)&set(anchor.seq));assert len(ids)==240
    for label,q in [('Frozen',frozen[frozen.seq.isin(ids)]),('Refit',anchor[anchor.seq.isin(ids)])]:
        q=q.sort_values('seq');assert q.seq.tolist()==ids
        y=q.prediction_mm.to_numpy();valid=np.isfinite(y)&(y>0)&(q.K.to_numpy()>0)
        rows.append(dict(session=se,calibration=label,K=float(q.K.iloc[0]),d0=float(q.d0.iloc[0]),
            **metric(q,q.signed_error_mm,valid,valid&q.gate_accept.to_numpy())))
        frames.extend(dict(session=se,seq=int(x.seq),true_m=float(x.true_m),calibration=label,prediction_mm=float(x.prediction_mm),
             signed_error_mm=float(x.signed_error_mm),reported=bool(x.gate_accept)) for _,x in q.iterrows())
pd.DataFrame(rows).to_csv(A/'paired_calibration_metrics.csv',index=False)
pd.DataFrame(frames).to_csv(A/'paired_calibration_frames.csv',index=False)

common=[];inventory=[]
for (se,prot),g in b.groupby(['session','protocol'],sort=False):
    ids_by={be:set(q[q.range_valid].seq) for be,q in g.groupby('backend')}
    ids=sorted(set.intersection(*ids_by.values()));assert len(ids)==(202 if se.startswith('S10_') and prot=='two_anchor_heldout' else (240 if prot=='two_anchor_heldout' else 300))
    attempted=g[g.backend=='libSGM'].seq.nunique()
    for be,q0 in g.groupby('backend',sort=False):
        q=q0[q0.seq.isin(ids)].sort_values('seq');assert q.seq.tolist()==ids
        common.append(dict(session=se,protocol=prot,backend=be,full_attempted_n=attempted,
            full_valid_n=int(q0.range_valid.sum()),full_reported_n=int(q0.gate_accept.sum()),
            common_n=len(ids),**metric(q,q.error_mm,np.ones(len(q),bool),q.gate_accept.to_numpy())))
        inventory.extend(dict(session=se,protocol=prot,backend=be,seq=int(x.seq),true_m=float(x.true_m),prediction_mm=float(x.prediction_mm),signed_error_mm=float(x.error_mm),reported=bool(x.gate_accept)) for _,x in q.iterrows())
pd.DataFrame(common).to_csv(A/'backend_common_valid_metrics.csv',index=False)
pd.DataFrame(inventory).to_csv(A/'backend_common_valid_frames.csv',index=False)
old=pd.read_csv(A/'backend_common_subset.csv')
for row in common:
    q=old[(old.session==row['session'])&(old.protocol==row['protocol'])&(old.backend==row['backend'])].iloc[0]
    assert int(q.common_n)==row['common_n']
    for col in ['MAPE','MAE_mm','p95_mm','max_mm']:assert np.isclose(q[col],row[col],atol=1e-8),col
out=dict(status='passed',paired_calibration_rows=len(rows),paired_frame_rows=len(frames),common_valid_rows=len(common),
    scope='Descriptive paired summaries on identical frame IDs; no significance tests on consecutive frames, model fitting, or new acquisition.',
    quantile='numpy.percentile(..., method=linear), rank h=(n-1)*0.95',incomplete_S8a='No 4m anchor; excluded from paired protocol, retained in frozen full-run inventory.')
(A/'paired_analysis_audit.json').write_text(json.dumps(out,indent=2),encoding='utf8')
print(pd.DataFrame(rows)[['session','calibration','attempted_n','MAPE','MAE_mm','p95_mm','max_mm','gt500_n']].round(3).to_string(index=False))
print('S10 common validity:')
print(pd.DataFrame(common)[lambda x:x.session.str.startswith('S10_')&x.protocol.eq('two_anchor_heldout')][['backend','common_n','MAPE','MAE_mm','p95_mm','gt500_n']].round(3).to_string(index=False))
print(json.dumps(out,indent=2))
