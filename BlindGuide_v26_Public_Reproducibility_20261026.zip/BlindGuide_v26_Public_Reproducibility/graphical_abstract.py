"""Independent graphical abstract from supplied ROI geometry and fixed results."""
from pathlib import Path
import json
import numpy as np,pandas as pd,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch
from PIL import Image
R=Path(__file__).resolve().parent;O=R/'deliverables';O.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','svg.fonttype':'none','pdf.fonttype':42})
fig=plt.figure(figsize=(6.6,2.95),facecolor='white')
ax=fig.add_axes([0,0,1,1]);ax.set(xlim=(0,660),ylim=(0,295));ax.axis('off')
blue='#17659e';orange='#ab431d';dark='#172b3b';pink='#9e2356'
ax.text(330,278,'Calibration and tail errors in stereo range',ha='center',va='center',fontsize=15,color=dark,weight='bold')
for x in [220,440]:ax.plot([x,x],[50,247],color='#ccd4db',lw=.8)
for x,title in [(110,'Region + coordinates'),(330,'One frozen transfer'),(550,'Reported error tails')]:
    ax.text(x,232,title,ha='center',fontsize=11.8,color=dark,weight='bold')
# Actual S1 frame-105 boundaries, with no photograph.
roi=fig.add_axes([.032,.285,.267,.37]);z=np.load(R/'representatives/S1_regions_105.npz')
x0,y0=z['crop_origin'];xx=np.arange(z['mask'].shape[1])+x0;yy=np.arange(z['mask'].shape[0])+y0
for name,col in [('person',pink),('board',blue)]:
    for suffix,style in [('direct','solid'),('mapped','dashed')]:
        roi.contour(xx,yy,z[name+'_'+suffix]>0,levels=[.5],colors=[col],linestyles=[style],linewidths=[1.2])
roi.set(xlim=(535,755),ylim=(590,240));roi.set_xticks([]);roi.set_yticks([])
for spine in roi.spines.values():spine.set_color('#ccd4db')
ax.text(110,65,'Same 300 S1 frames',ha='center',fontsize=11.7,color=dark)
ax.text(110,44,'Raw → rectified',ha='center',fontsize=11.7,color=dark)
ax.text(330,184,'C0',ha='center',fontsize=17,color=blue,weight='bold')
ax.add_patch(FancyArrowPatch((330,172),(330,144),arrowstyle='-|>',mutation_scale=12,color=blue,lw=1.4))
ax.text(330,122,'C1',ha='center',fontsize=17,color=blue,weight='bold')
ax.text(330,90,'2.76% MAPE',ha='center',fontsize=14,color=dark,weight='bold')
ax.text(330,65,'300 test frames',ha='center',fontsize=11.7,color=dark)
ax.text(330,44,'Nominal distance labels',ha='center',fontsize=11.7,color=dark)
ax.text(550,175,'208 / 240',ha='center',fontsize=20,color=blue,weight='bold')
ax.text(550,151,'frames reported',ha='center',fontsize=11.7,color=dark)
ax.text(550,104,'5 / 208',ha='center',fontsize=20,color=orange,weight='bold')
ax.text(550,80,'errors >500 mm',ha='center',fontsize=11.7,color=dark)
ax.text(550,44,'OpenCV / S7',ha='center',fontsize=11.7,color=dark)
ax.text(330,15,'Fixed image regions and frame IDs reveal changes in reported error.',ha='center',fontsize=11.5,color=dark)
for ext in ['svg','pdf']:fig.savefig(O/('gagraphic.'+ext),facecolor='white')
fig.savefig(O/'gagraphic.png',dpi=100,facecolor='white')
with Image.open(O/'gagraphic.png') as im:
    assert im.size==(660,295)
    # Lossless palette encoding keeps the journal-sized graphic below 45 KB.
    im.convert('RGB').quantize(colors=128).save(O/'gagraphic.png',optimize=True,dpi=(300,300))
fig.savefig(O/'gagraphic_high_resolution.png',dpi=300,facecolor='white')
plt.close(fig)
caption='Graphical abstract. Target-level stereo errors are examined through fixed ROI geometry, calibration provenance and reported populations. One operator-documented C0-to-C1 reset gives 2.76% MAPE on 300 frames against nominal distance labels. In the separate OpenCV/S7 two-anchor test, the fixed reporting rule retains 208/240 frames and passes 5 errors above 500 mm among its 208 reports. The S1 boundaries are actual archived ROI geometry; no human photograph is used.'
(O/'gacaption.txt').write_text(caption+'\n',encoding='utf8')
assert (O/'gagraphic.png').stat().st_size<45000
print('Independent gagraphic:',Image.open(O/'gagraphic.png').size,(O/'gagraphic.png').stat().st_size,'bytes; 300 dpi metadata')
