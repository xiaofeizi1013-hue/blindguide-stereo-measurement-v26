"""Rebuild all 300 S1 fixed-input masks; --remap additionally requires OpenCV."""
from pathlib import Path
import argparse,json
import numpy as np,pandas as pd
R=Path(__file__).resolve().parent
ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--out',default='rebuilt_masks');ap.add_argument('--remap',action='store_true');args=ap.parse_args()
out=Path(args.out);out=out.resolve() if out.is_absolute() else (R/out).resolve()
assert out!=R and out not in R.parents
assert not any(out==R/name or R/name in out.parents for name in ['analysis','reproducibility','representatives','authoring','figures','audit'])
out.mkdir(parents=True,exist_ok=True)
if args.remap:
    import cv2
    c=np.load(R/'reproducibility/calibration/stereo_calib.npz');size=tuple(map(int,c['image_size']))
    r1,_,p1,*_=cv2.stereoRectify(c['K1'],c['D1'],c['K2'],c['D2'],size,c['R'],c['T'],alpha=0)
    maps=cv2.initUndistortRectifyMap(c['K1'],c['D1'],r1,p1,size,cv2.CV_32FC1)
    expected=pd.read_csv(R/'analysis/sources/board_features.csv');expected=expected[expected.session=='S1'].set_index('seq')
f=pd.read_csv(R/'reproducibility/roi/S1_person_boxes.csv')
for _,q in f.iterrows():
    m=np.zeros((720,1280),np.uint8);m[q.core_y_start:q.core_y_stop,q.core_x_start:q.core_x_stop]=255
    data={'person_direct':m}
    if args.remap:
        mapped=cv2.remap(m,*maps,cv2.INTER_NEAREST)
        n,labels,stats,_=cv2.connectedComponentsWithStats(mapped,8)
        if n>1:mapped=np.where(labels==1+np.argmax(stats[1:,cv2.CC_STAT_AREA]),255,0).astype('uint8')
        assert np.count_nonzero(mapped)==expected.loc[q.seq,'person_mapped_area']
        data['person_mapped']=mapped
    np.savez_compressed(out/f'S1_{q.seq:05d}.npz',**data)
print(f'Rebuilt {len(f)} fixed-input masks; remapped={args.remap}; output={out}')
