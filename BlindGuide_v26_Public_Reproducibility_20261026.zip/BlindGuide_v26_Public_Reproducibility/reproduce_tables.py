"""Generate numerical table data from the packaged frame records."""
from pathlib import Path
import numpy as np,pandas as pd
R=Path(__file__).resolve().parent;A=R/'analysis';O=R/'tables';O.mkdir(exist_ok=True)
p=pd.read_csv(A/'predictions.csv');pair=pd.read_csv(A/'paired_calibration_metrics.csv');re=pd.read_csv(A/'reset_metrics.csv')
rows=[]
for se,q in p[p.protocol=='frozen_S1'].groupby('session',sort=False):
    full=abs(q.signed_error_mm.to_numpy());full_mape=np.mean(full/(q.true_m.to_numpy()*1000))*100
    a=pair[(pair.session==se)&(pair.calibration=='Refit')];f=pair[(pair.session==se)&(pair.calibration=='Frozen')]
    row=dict(session=se,captured_n=len(q),frozen_full_MAPE=full_mape,frozen_paired_MAPE=float(f.MAPE.iloc[0]) if len(f) else np.nan,refit_paired_MAPE=float(a.MAPE.iloc[0]) if len(a) else np.nan,
        refit_p95_mm=float(a.p95_mm.iloc[0]) if len(a) else np.nan,refit_max_mm=float(a.max_mm.iloc[0]) if len(a) else np.nan,refit_gt500_n=int(a.gt500_n.iloc[0]) if len(a) else np.nan)
    rows.append(row)
f=re[re.label=='C1 frozen C0 all10 300'].iloc[0];fc=re[re.label=='C1 frozen C0 common8 240'].iloc[0];a=re[re.label=='C1 refit heldout8 240'].iloc[0]
rows.append(dict(session='C1 reset',captured_n=300,frozen_full_MAPE=f.MAPE,frozen_paired_MAPE=fc.MAPE,refit_paired_MAPE=a.MAPE,refit_p95_mm=a.p95_mm,refit_max_mm=a.max_mm,refit_gt500_n=a.gt_500mm_n))
pd.DataFrame(rows).to_csv(O/'Table_III.csv',index=False)
copies={'mapping_2x2_results.csv':'Table_II.csv','reported_backend_metrics.csv':'Table_IV_and_S11.csv','tail_metrics.csv':'Table_S4.csv','backend_metrics.csv':'Table_S6.csv','reset_metrics.csv':'Table_S8.csv',
        'reset_per_distance.csv':'Table_S9.csv','anchor_disparity_summary.csv':'Table_S12.csv','paired_calibration_metrics.csv':'Table_S14.csv','backend_common_valid_metrics.csv':'Table_S15.csv'}
for source,dest in copies.items():pd.read_csv(A/source).to_csv(O/dest,index=False)
per=pd.read_csv(A/'reported_backend_per_distance.csv')
per[(per.backend=='OpenCV_SGBM')&per.session.str.startswith('S7_')&(per.protocol=='two_anchor_heldout')].to_csv(O/'Table_S13.csv',index=False)
print('Generated',len(list(O.glob('*.csv'))),'full-precision numerical table CSVs.')
