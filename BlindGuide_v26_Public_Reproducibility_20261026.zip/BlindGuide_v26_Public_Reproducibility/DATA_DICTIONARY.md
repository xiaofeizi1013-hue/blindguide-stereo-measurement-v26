# Data dictionary

Coordinates and model units are px and mm unless stated otherwise. Nominal distances true_m are in metres. UTF-8 CSVs retain full precision; display rounding is separate. Composite identifiers are session and seq, with backend/protocol/estimator added where those vary.

| Record | Core fields and meaning |
|---|---|
| analysis/predictions.csv | Archived board protocols: session, seq, true_m, protocol, K (mm·px), d0 (px), d, MAD, prediction_mm, signed_error_mm, gate_accept, source frame |
| analysis/backend_features.csv | One row per backend/source frame; d is final trimmed median, d_untrim is initial median, mad is initial spatial MAD, n/area valid pixel count/mask area, valid_fraction=n/area, n_trim count after trimming; computable requires n≥30 and valid_fraction≥0.25 |
| analysis/backend_predictions.csv | One row per backend/session/protocol/seq; range_valid identifies finite positive range with K>0; score_pass is MAD≤3 and n≥10; gate_accept combines physical validity with the reporting score |
| analysis/reset_predictions.csv | C0/C1 protocol, training-independent frame ID, z_ref_mm, z_pred_mm, abs_error_mm, ape_pct; reported is the final reporting decision; C1 refit all-frame rows include anchors |
| analysis/paired_calibration_frames.csv | Frozen/refit predictions on identical 240 non-anchor IDs; calibration identifies the conversion; no distance group is removed because of error |
| analysis/backend_common_valid_frames.csv | Both backends on the same positive-range-ID intersection; invalid conversions remain in the full protocol inventory and are not encoded as zero error |
| representatives/*.npz | left/right board-only display arrays (background white; S1-105 blank geometry-only background); raw_left is blank in all six cases; libSGM/OpenCV_SGBM disparity arrays; mask uint8; crop_origin=[x0,y0] on the working grid; S1 region case also stores all four masks |
| representatives/sift_correspondences.csv | Original global x_left/y_left/x_right/y_right; nearest and second distances; ratio_pass/mutual_pass/geometric_pass and retained flags; disparity_px=x_left−x_right |
| representatives/marker_correspondences.csv | Decoded marker_id and corner_index with global coordinates, ROI and geometric flags; ambiguous duplicate IDs are not paired |
| representatives/cases_manifest.json | Fixed case selection, raw source SHA-256, full crop bounds, before/after counts, sparse candidate/retained counts |
| reproducibility/training_frame_index.csv | Training key, training session/frame, nominal distance, source frame and SHA-256 |
| reproducibility/protocol_index.csv | Evaluation protocol to training-key mapping, training count, attempted test count and source predictions |

Statistical definitions: MAE=mean(abs(error)), MAPE=100*mean(abs(error)/reference_mm), p95=numpy.percentile(abs(error),95,method='linear'). Exceedances use strict > on unrounded errors. Empty report sets have missing error statistics. A 0/0 count cell has no estimated fraction.

Unknown physical fields remain unknown: exact board reference-point image coordinate, tape-line direction, camera-end datum, illuminance, physical serial and verified focus-lock evidence. C1 known metadata remain 22°C, target-center height 900mm, tilt 2–3° with nominal 2.5°. C0 missing numeric values are not imputed from C1.

ROI input fields: reproducibility/roi/S1_person_boxes.csv contains session, seq, frame, frame_sha256, raw_person_box, integer x1/y1/x2/y2, archived box_source, core_x_start/core_y_start/core_x_stop/core_y_stop, core_area_px and source_rectified_flag. The last field concerns disparity-map processing, not detector-image coordinates. The raw origin is the working left-eye top-left after the 120:840 vertical crop. Core slices are half-open, clipped before int truncation. S1_box_protocol.json gives exact formulas. The archived coordinates and source hashes are fixed experimental inputs; detector inference is not reproduced.

Image-display processing: representatives/ contains derived visualization pixels rather than unmodified human photographs. Outside-board pixels are white, and the S1 region-ablation case contains only numeric mask geometry. Right display masks use the median retained SIFT displacement. Original full-frame digests still identify the private originals. The dense disparity arrays, ROI masks and feature coordinates retain their original numerical values. No matching output is recomputed from a masked display image.
