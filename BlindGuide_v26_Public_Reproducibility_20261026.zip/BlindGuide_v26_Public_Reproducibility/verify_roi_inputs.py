"""Verify archived person-box inputs without detector inference or raw images."""
from pathlib import Path
import json
import numpy as np,pandas as pd
R=Path(__file__).resolve().parent
f=pd.read_csv(R/'reproducibility/roi/S1_person_boxes.csv')
b=pd.read_csv(R/'analysis/sources/board_features.csv');b=b[b.session=='S1'].set_index('seq')
assert len(f)==300 and f.seq.tolist()==list(range(1,301))
for _,q in f.iterrows():
    x1,y1,x2,y2=json.loads(q.raw_person_box);w=x2-x1;h=y2-y1
    bounds=[int(max(0,x1+.22*w)),int(max(0,y1+.22*h)),int(min(1280,x2-.22*w)),int(min(720,y2-.22*h))]
    assert bounds==[q.core_x_start,q.core_y_start,q.core_x_stop,q.core_y_stop]
    a,c,d,e=bounds;area=(d-a)*(e-c)
    assert area==q.core_area_px==b.loc[q.seq,'person_old_area']
    assert q.frame_sha256==b.loc[q.seq,'frame_sha256'] and len(q.frame_sha256)==64
z=np.load(R/'representatives/S1_regions_105.npz');q=f[f.seq==105].iloc[0]
m=np.zeros((720,1280),np.uint8);m[q.core_y_start:q.core_y_stop,q.core_x_start:q.core_x_stop]=255
ox,oy=map(int,z['crop_origin']);hh,ww=z['person_direct'].shape
assert np.array_equal(m[oy:oy+hh,ox:ox+ww],z['person_direct'])
out=dict(status='passed',archived_boxes=300,raw_core_areas_matched=300,frame_hash_links_matched=300,
    representative_direct_mask_exact=True,scope='Fixed input coordinates and derived masks, not detector regeneration.')
(R/'analysis/roi_input_verification.json').write_text(json.dumps(out,indent=2),encoding='utf8')
print(json.dumps(out,indent=2))
