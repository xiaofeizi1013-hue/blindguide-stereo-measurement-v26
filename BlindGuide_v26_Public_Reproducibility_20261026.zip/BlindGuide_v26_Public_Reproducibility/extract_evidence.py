"""Replay six fixed representative pairs and preserve image-level evidence caches.

Raw images are read locally; shareable caches contain cropped target views.
All crop origins, masks, disparities, features and filtering flags are retained.
"""
from pathlib import Path
import ast,hashlib,json,sys,importlib.util,platform,argparse,os
import cv2,numpy as np,pandas as pd
R=Path(__file__).resolve().parent;A=R/'analysis';E=R/'representatives';E.mkdir(exist_ok=True)
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--runtime-root',type=Path,default=Path('D:/MIMO/blindguide/blindguide_runtime'),help='Original data/sessions and legacy wrapper checkout; full-image replay only.')
args=parser.parse_args();ROOT=args.runtime_root;DATA=ROOT/'data/sessions'
CAL=R/'reproducibility/calibration/stereo_calib.npz'
cal=np.load(CAL);size=tuple(map(int,cal['image_size']))
assert size==(1280,720)
r1,r2,p1,p2,*_=cv2.stereoRectify(cal['K1'],cal['D1'],cal['K2'],cal['D2'],size,cal['R'],cal['T'],alpha=0)
maps=[cv2.initUndistortRectifyMap(cal[f'K{i}'],cal[f'D{i}'],r,p,size,cv2.CV_32FC1) for i,r,p in [(1,r1,p1),(2,r2,p2)]]
for target in [R/'reproducibility/calibration',R/'reproducibility/software']:target.mkdir(parents=True,exist_ok=True)
(R/'reproducibility/calibration/stereo_calib.npz').write_bytes(CAL.read_bytes())
packed=R/'reproducibility/software'
wrapper=packed/'sgm_match.py' if (packed/'sgm_match.py').exists() else ROOT/'src/stereo/sgm_match.py'
if (packed/'sgm_c_api.dll').exists():os.environ['SGM_LIB_PATH']=str(packed/'sgm_c_api.dll')
spec=importlib.util.spec_from_file_location('frozen_sgm_wrapper',wrapper)
sgm_mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(sgm_mod)
matcher=sgm_mod.get_matcher(1280,720,128)
cfg=json.loads((A/'backend_configuration.json').read_text());sgbm=cv2.StereoSGBM_create(**cfg['opencv_config'])
cv2.setNumThreads(4);sf=cv2.SIFT_create(contrastThreshold=.01);bf=cv2.BFMatcher()
dp=cv2.aruco.DetectorParameters();dp.cornerRefinementMethod=cv2.aruco.CORNER_REFINE_SUBPIX
det=cv2.aruco.ArucoDetector(cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_250),dp)
old=pd.read_csv(A/'sources/board_features.csv');cache=pd.read_csv(A/'backend_features.csv')
seeds=json.loads((A/'sources/new_seeds.json').read_text(encoding='utf8'))

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def order(poly):
    p=np.float32(poly);s=p.sum(axis=1);d=np.diff(p,axis=1).ravel()
    return np.array([p[np.argmin(s)],p[np.argmin(d)],p[np.argmax(s)],p[np.argmax(d)]],np.float32)
def inner(poly,f=.7):
    a=(1-f)/2;src=np.float32([[0,0],[1,0],[1,1],[0,1]])
    dst=np.float32([[a,a],[1-a,a],[1-a,1-a],[a,1-a]])
    return cv2.perspectiveTransform(dst.reshape(-1,1,2),cv2.getPerspectiveTransform(src,order(poly))).reshape(4,2)
def polymask(poly):
    out=np.zeros((720,1280),np.uint8);cv2.fillConvexPoly(out,np.rint(poly).astype('int32'),255);return out
def mapped(mask):
    out=cv2.remap(mask,*maps[0],cv2.INTER_NEAREST);n,lab,stats,_=cv2.connectedComponentsWithStats(out,8)
    return np.where(lab==1+np.argmax(stats[1:,cv2.CC_STAT_AREA]),255,0).astype(np.uint8) if n>1 else out
def stats(d,mask):
    vals=d[(mask>0)&(d>.5)];med=float(np.median(vals));mad=float(np.median(abs(vals-med)))
    trimmed=vals[abs(vals-med)<=max(1.5,2.5*mad)] if mad>.1 else vals
    return dict(d=float(np.median(trimmed)),d_untrim=med,mad=mad,n=len(vals),n_trim=len(trimmed),area=int(np.count_nonzero(mask)))
def read(name,seq):
    rec=cache[(cache.backend=='libSGM')&(cache.session==name)&(cache.seq==seq)].iloc[0]
    path=DATA/name/'frames'/rec.frame;assert sha(path)==rec.frame_sha256
    im=cv2.imdecode(np.frombuffer(path.read_bytes(),np.uint8),cv2.IMREAD_COLOR)
    assert im.shape==(960,2560,3)
    gl=cv2.cvtColor(im[120:840,:1280],cv2.COLOR_BGR2GRAY)
    gr=cv2.cvtColor(im[120:840,1280:],cv2.COLOR_BGR2GRAY)
    return rec,gl,gr,cv2.remap(gl,*maps[0],cv2.INTER_LINEAR),cv2.remap(gr,*maps[1],cv2.INTER_LINEAR)
def boardmask(name,seq,gl):
    if name.startswith('S1_'):
        rec=old[(old.session_name==name)&(old.seq==seq)].iloc[0]
        raw=polymask(inner(json.loads(rec.raw_board_polygon)));return mapped(raw),raw
    if name.startswith('S10_'):
        boxes=json.loads((DATA/name/'S10_board_boxes.json').read_text(encoding='utf8'))
        z=float(cache[(cache.session==name)&(cache.seq==seq)].true_m.iloc[0]);x1,y1,x2,y2=boxes[f'{z:.1f}']
        out=np.zeros((720,1280),np.uint8);mx=(x2-x1)*.15;my=(y2-y1)*.15
        out[int(y1+my):int(y2-my),int(x1+mx):int(x2-mx)]=255;return out,None
    seed=next(x for x in seeds if x['name']==name and x['true_m']==2.)
    poly=order(seed['best']['p'])
    if seq!=seed['seq']:
        _,first,*_=read(name,seed['seq'])
        p0=cv2.goodFeaturesToTrack(first,220,.01,2,mask=polymask(inner(poly,.9)))
        pf,ok,_=cv2.calcOpticalFlowPyrLK(first,gl,p0,None,winSize=(15,15),maxLevel=3)
        pb,bk,_=cv2.calcOpticalFlowPyrLK(gl,first,pf,None,winSize=(15,15),maxLevel=3)
        good=(ok.ravel()>0)&(bk.ravel()>0)&(np.linalg.norm(pb-p0,axis=2).ravel()<.7)
        H,_=cv2.findHomography(p0[good],pf[good],cv2.RANSAC,.8)
        poly=order(cv2.perspectiveTransform(poly.reshape(-1,1,2),H).reshape(4,2))
    raw=polymask(inner(poly));return mapped(raw),raw

all_sift=[];all_markers=[];cases=[];checks=[]
def sparse(rl,rr,mask,tag):
    yy,xx=np.where(mask>0);x1,x2=int(xx.min()),int(xx.max()+1);y1,y2=int(yy.min()),int(yy.max()+1)
    rm=np.zeros_like(mask);rm[max(0,y1-4):min(720,y2+4),max(0,x1-128):x2]=255
    kl,dl=sf.detectAndCompute(rl,mask);kr,dr=sf.detectAndCompute(rr,rm);out=[]
    if dl is None or dr is None or len(dl)<2 or len(dr)<2:return out
    ab=bf.knnMatch(dl,dr,k=2);ba=bf.knnMatch(dr,dl,k=2)
    reverse={m[0].queryIdx:m[0].trainIdx for m in ba if len(m)==2 and m[0].distance<.7*m[1].distance}
    for pair in ab:
        if len(pair)!=2:continue
        m,n=pair;u=kl[m.queryIdx].pt;v=kr[m.trainIdx].pt;dx=u[0]-v[0]
        ratio=m.distance<.7*n.distance;mutual=reverse.get(m.trainIdx)==m.queryIdx
        geo=.5<dx<=128 and abs(u[1]-v[1])<=1.5
        out.append(dict(case=tag,query_idx=m.queryIdx,train_idx=m.trainIdx,x_left=u[0],y_left=u[1],x_right=v[0],y_right=v[1],
            disparity_px=dx,vertical_px=u[1]-v[1],nearest_distance=m.distance,second_distance=n.distance,
            ratio_pass=ratio,mutual_pass=mutual,geometric_pass=geo,retained=bool(ratio and mutual and geo)))
    return out
def markers(rl,rr,mask,tag):
    def unique(image):
        corners,ids,_=det.detectMarkers(image)
        if ids is None:return {}
        ids=ids.ravel();return {int(i):corners[k].reshape(4,2) for k,i in enumerate(ids) if (ids==i).sum()==1}
    left=unique(rl);right=unique(rr);out=[]
    for mid in sorted(set(left)&set(right)):
        for idx,(u,v) in enumerate(zip(left[mid],right[mid])):
            x,y=int(round(u[0])),int(round(u[1]));inside=0<=x<1280 and 0<=y<720 and bool(mask[y,x]);dx=float(u[0]-v[0]);geo=.5<dx<=128 and abs(float(u[1]-v[1]))<=1.5
            out.append(dict(case=tag,marker_id=mid,corner_index=idx,x_left=float(u[0]),y_left=float(u[1]),x_right=float(v[0]),y_right=float(v[1]),disparity_px=dx,in_roi=inside,geometric_pass=geo,retained=bool(inside and geo)))
    return out

selected=[('S1_20261019_2135',105,'S1_regions_105'),('S1_20261019_2135',31,'S1_anchor_high_31'),('S1_20261019_2135',32,'S1_anchor_low_32'),
          ('S7_RESET_20261024_1540',91,'S7_failure_91'),('S7_RESET_20261024_1540',92,'S7_next_92'),('S10_STAND_20261024_1615',75,'S10_supported_75')]
for name,seq,tag in selected:
    rec,gl,gr,rl,rr=read(name,seq);mask,rawboard=boardmask(name,seq,gl)
    lg=matcher.compute(rl,rr);cv=sgbm.compute(rl,rr).astype(np.float32)/16
    st={be:stats(d,mask) for be,d in [('libSGM',lg),('OpenCV_SGBM',cv)]}
    for be,vals in st.items():
        oldrec=cache[(cache.session==name)&(cache.seq==seq)&(cache.backend==be)].iloc[0]
        delta={k:float(vals[k]-oldrec[k]) for k in ['d','d_untrim','mad','n','n_trim','area']}
        assert all(abs(v)<1e-8 for v in delta.values()),(tag,be,delta)
        checks.append(dict(case=tag,backend=be,differences_from_cached=delta))
    if tag=='S1_regions_105':
        legacy=pd.read_csv(DATA/name/'features.csv');q=legacy[(legacy.seq==seq)&(legacy.task=='accuracy')&(legacy.target=='board')].iloc[0]
        x1,y1,x2,y2=ast.literal_eval(q.box);w=x2-x1;h=y2-y1
        pm=np.zeros_like(mask);pm[int(max(0,y1+.22*h)):int(min(720,y2-.22*h)),int(max(0,x1+.22*w)):int(min(1280,x2-.22*w))]=255
        extra=dict(person_direct=pm,person_mapped=mapped(pm),board_direct=rawboard,board_mapped=mask)
        union=np.logical_or.reduce([v>0 for v in extra.values()])
    else:extra={};union=mask>0
    yy,xx=np.where(union);x0=max(0,int(xx.min())-150);x2=min(1280,int(xx.max())+26);y0=max(0,int(yy.min())-24);y2=min(720,int(yy.max())+25)
    sl=np.s_[y0:y2,x0:x2]
    sfrows=sparse(rl,rr,mask,tag);mkrows=markers(rl,rr,mask,tag)
    all_sift.extend(sfrows);all_markers.extend(mkrows)
    sfkeep=[x for x in sfrows if x['retained']];mkkeep=[x for x in mkrows if x['retained']]
    shift=float(np.median([x['disparity_px'] for x in sfkeep])) if sfkeep else 0.
    lm=mask>0;rm=cv2.warpAffine(lm.astype('uint8'),np.float32([[1,0,-shift],[0,1,0]]),(1280,720),flags=cv2.INTER_NEAREST)>0
    rawm=(rawboard>0) if rawboard is not None else lm
    if tag=='S1_regions_105':lm=np.zeros_like(lm);rm=np.zeros_like(rm);rawm=np.zeros_like(rawm)
    np.savez_compressed(E/(tag+'.npz'),left=np.where(lm,rl,255).astype('uint8')[sl],
        right=np.where(rm,rr,255).astype('uint8')[sl],raw_left=np.full_like(gl,255)[sl],mask=mask[sl],
        libSGM=lg[sl],OpenCV_SGBM=cv[sl],crop_origin=np.array([x0,y0]),**{k:v[sl] for k,v in extra.items()})
    cases.append(dict(case=tag,session=name,seq=seq,frame=rec.frame,nominal_m=float(rec.true_m),source_sha256=rec.frame_sha256,
        cache_file=tag+'.npz',crop_xyxy=[x0,y0,x2,y2],statistics=st,sift_candidate_n=len(sfrows),sift_retained_n=len(sfkeep),
        sift_median_px=float(np.median([x['disparity_px'] for x in sfkeep])) if sfkeep else None,
        marker_candidate_n=len(mkrows),marker_retained_n=len(mkkeep),right_display_shift_px=shift,
        display_processing='White background outside board-core pixels; S1 region panel contains geometry only. Full original stereo images are not shared.'))
    print(tag,'d',st['libSGM']['d'],st['OpenCV_SGBM']['d'],'SIFT',len(sfkeep),'markers',len(mkkeep),flush=True)
matcher.close()
pd.DataFrame(all_sift).to_csv(E/'sift_correspondences.csv',index=False)
pd.DataFrame(all_markers).to_csv(E/'marker_correspondences.csv',index=False)
(E/'cases_manifest.json').write_text(json.dumps(cases,ensure_ascii=False,indent=2),encoding='utf8')
(A/'image_evidence_replay_check.json').write_text(json.dumps(dict(status='passed',case_count=len(cases),backend_rows=len(checks),checks=checks),indent=2),encoding='utf8')
info=cv2.getBuildInformation();(R/'reproducibility/software/opencv_build_information.txt').write_text(info,encoding='utf8')
pyd=list(Path(cv2.__file__).parent.glob('*.pyd'));assert len(pyd)==1
env=dict(python=sys.version,numpy=np.__version__,opencv=cv2.__version__,platform=platform.platform(),
    opencv_version_control=next(x.split(':',1)[1].strip() for x in info.splitlines() if 'Version control:' in x),
    opencv_module_binary=dict(name=pyd[0].name,sha256=sha(pyd[0])),
    calibration=dict(file='calibration/stereo_calib.npz',sha256=sha(CAL)),
    libsgm_binary=dict(name='sgm_c_api.dll',sha256=sha(ROOT/'libSGM/dist/sgm_c_api.dll')),
    raw_image_access='Original unmodified stereo frames retained by authors; shared evidence caches contain target crops, masks and dense maps with full-image coordinate origins.',
    reference_point='Operator-selected board surface point; exact image coordinate, tape direction and camera-end datum were not recorded. No image point is inferred.')
(R/'reproducibility/software/extraction_environment.json').write_text(json.dumps(env,indent=2),encoding='utf8')
print('All 12 backend replays match preserved d, MAD, pixel counts and trimming counts.')
