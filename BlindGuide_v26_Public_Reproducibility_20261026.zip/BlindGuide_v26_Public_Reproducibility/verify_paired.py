from pathlib import Path
import json,numpy as np,pandas as pd
R=Path(__file__).resolve().parent;A=R/'analysis';E=R/'representatives'
p=pd.read_csv(A/'predictions.csv');pairs=pd.read_csv(A/'paired_calibration_metrics.csv')
assert len(pairs)==22
for _,row in pairs.iterrows():
    allrun=p[p.session==row.session]
    q=allrun[(allrun.protocol==('frozen_S1' if row.calibration=='Frozen' else 'two_anchor_heldout'))&~allrun.true_m.isin([1.,4.])].sort_values('seq')
    other=allrun[(allrun.protocol==('two_anchor_heldout' if row.calibration=='Frozen' else 'frozen_S1'))&~allrun.true_m.isin([1.,4.])].sort_values('seq')
    assert len(q)==240 and q.seq.tolist()==other.seq.tolist()
    y=q.K.to_numpy()/(q.d.to_numpy()-q.d0.to_numpy());e=abs(y-q.true_m.to_numpy()*1000)
    for key,val in dict(MAPE=np.mean(e/(q.true_m.to_numpy()*1000))*100,MAE_mm=e.mean(),p95_mm=np.quantile(e,.95,method='linear'),max_mm=e.max()).items():
        assert np.isclose(row[key],val,atol=1e-7,rtol=1e-10),(row.session,row.calibration,key)
    assert row.gt500_n==int((e>500).sum())
b=pd.read_csv(A/'backend_predictions.csv');common=pd.read_csv(A/'backend_common_valid_metrics.csv')
for (se,pr),group in common.groupby(['session','protocol']):
    g=b[(b.session==se)&(b.protocol==pr)]
    ids=set.intersection(*(set(q[q.range_valid].seq) for _,q in g.groupby('backend')))
    for _,row in group.iterrows():
        q=g[(g.backend==row.backend)&g.seq.isin(ids)];e=abs(q.error_mm.to_numpy())
        assert len(q)==row.common_n
        for key,val in dict(MAPE=np.mean(e/(q.true_m.to_numpy()*1000))*100,MAE_mm=e.mean(),p95_mm=np.percentile(e,95,method='linear'),max_mm=e.max()).items():assert np.isclose(row[key],val,atol=1e-7)
f=pd.read_csv(A/'backend_features.csv');cases=json.loads((E/'cases_manifest.json').read_text(encoding='utf8'))
sift=pd.read_csv(E/'sift_correspondences.csv');markers=pd.read_csv(E/'marker_correspondences.csv')
for case in cases:
    z=np.load(E/case['cache_file']);mask=z['mask']>0
    for be in ['libSGM','OpenCV_SGBM']:
        vals=z[be][mask&(z[be]>.5)];med=np.median(vals);mad=np.median(abs(vals-med))
        assert np.histogram(vals,bins=np.arange(.5,128.5,.5))[0].sum()==len(vals),'Disparity histogram must include every valid ROI pixel.'
        keep=vals[abs(vals-med)<=max(1.5,2.5*mad)] if mad>.1 else vals
        expected=f[(f.session==case['session'])&(f.seq==case['seq'])&(f.backend==be)].iloc[0]
        assert len(vals)==expected.n and len(keep)==expected.n_trim and np.count_nonzero(mask)==expected.area
        assert np.median(keep)==expected.d and mad==expected.mad
    ox,oy=z['crop_origin']
    for data in [sift,markers]:
        q=data[(data.case==case['case'])&data.retained]
        for _,m in q.iterrows():
            x=int(round(m.x_left-ox));y=int(round(m.y_left-oy))
            assert 0<=y<mask.shape[0] and 0<=x<mask.shape[1] and mask[y,x]
            assert np.isclose(m.disparity_px,m.x_left-m.x_right)
            assert abs(m.y_left-m.y_right)<=1.5 and .5<m.disparity_px<=128
assert np.percentile(np.r_[np.zeros(27),958.1],95,method='linear')==0
out=dict(status='passed',paired_rows=len(pairs),common_valid_rows=len(common),representative_pairs=len(cases),cached_backend_rows=12,all_retained_sparse_points_inside_ROI=True,
         scope='Verifies arithmetic, exact ID matching and supplied image caches. Does not certify reference geometry, reset actions or raw-image accessibility.')
(A/'v25_numeric_evidence_verification.json').write_text(json.dumps(out,indent=2),encoding='utf8');print(json.dumps(out,indent=2))
