"""Recompute the paper's numerical tables from packaged frame-level CSVs."""
from pathlib import Path
import numpy as np,pandas as pd,json
R=Path(__file__).parent;A=R/'analysis';src=A/'sources'
old=pd.read_csv(src/'board_features.csv');old['session']=old.session_name;new=pd.read_csv(src/'new_board_features.csv');data=pd.concat([old,new],ignore_index=True)
def stats(d,z,p,score):
 y=p[0]/(np.asarray(d)-p[1]);z=np.asarray(z);valid=np.isfinite(y)&(y>0)&(p[0]>0);e=y-z;v=abs(e[valid]);score=np.asarray(score)
 out=dict(n=len(z),finite_positive_n=int(valid.sum()),invalid_range_n=int((~valid).sum()),MAPE=float(np.mean(v/z[valid])*100),p95_mm=float(np.percentile(v,95)),max_mm=float(np.max(v)),gate_accept_n=int((valid&score).sum()))
 for t in [250,500,1000]:
  bad=valid&(abs(e)>t);out[f'abs_gt_{t}mm_n']=int(bad.sum());out[f'abs_gt_{t}mm_accepted_n']=int((bad&score).sum())
 bad=valid&(abs(e)/z>.20);out['rel_gt_20pct_n']=int(bad.sum());out['rel_gt_20pct_accepted_n']=int((bad&score).sum())
 return out
def fit(d,z):return 45870.,float(np.mean(np.asarray(d)-45870./np.asarray(z)))
def anchors(g,col):
 a=g.groupby('true_m')[col].median();k=float((a.loc[1.]-a.loc[4.])/(.001-.00025));return k,float(a.loc[1.]-k*.001)
def check(actual,expected,keys):
 for key in keys:assert np.isclose(actual[key],expected[key],rtol=1e-9,atol=1e-7),(key,actual[key],expected[key])
tail=pd.read_csv(A/'tail_metrics.csv');s1=data[data.session.str.startswith('S1_')];fr=fit(s1.board70_d,s1.true_m*1000);checked=0
for name,g in data.groupby('session'):
 for protocol in ['frozen_S1','two_anchor_heldout']:
  target=tail[(tail.session==name)&(tail.protocol==protocol)]
  if not len(target):continue
  q=g if protocol=='frozen_S1' else g[~g.true_m.isin([1.,4.])];pars=fr if protocol=='frozen_S1' else anchors(g,'board70_d');m=stats(q.board70_d,q.true_m*1000,pars,(q.board70_mad<=3)&(q.board70_n>=10));check(m,target.iloc[0],list(m));checked+=1
ab=pd.read_csv(A/'mapping_2x2_features.csv');mexp=pd.read_csv(A/'mapping_2x2_results.csv')
for label,g in ab.groupby('estimator'):
 z=g.true_m.to_numpy()*1000;d=g.d.to_numpy();params=fit(d,z);m=stats(d,z,params,np.ones(len(g),bool));ex=mexp[mexp.estimator==label].iloc[0];check(m,ex,['MAPE','p95_mm']);assert np.isclose(params[1],ex.d0)
 lo=np.zeros(len(g))
 for zz in np.unique(z):
  tr=z!=zz;pp=fit(d[tr],z[tr]);lo[~tr]=pp[0]/(d[~tr]-pp[1])
 assert np.isclose(float(np.mean(abs(lo-z)/z)*100),ex.LODO_MAPE)
 common=stats(d,z,(45870.,-2.4591047619047615),np.ones(len(g),bool));assert np.isclose(common['MAPE'],ex.legacy_offset_MAPE);checked+=1
bf=pd.read_csv(A/'backend_features.csv');be=pd.read_csv(A/'backend_metrics.csv')
for _,ex in be.iterrows():
 g=bf[(bf.backend==ex.backend)&(bf.session==ex.session)];tr=bf[(bf.backend==ex.backend)&bf.session.str.startswith('S1_')];pp=fit(tr.d,tr.true_m*1000) if ex.protocol=='frozen_S1' else anchors(g,'d')
 q=g if ex.protocol=='frozen_S1' else g[~g.true_m.isin([1.,4.])];m=stats(q.d,q.true_m*1000,pp,(q.mad<=3)&(q.n>=10)&q.computable);check(m,ex,list(m));checked+=1
report=dict(status='passed',table_rows_recomputed=checked,board_frames=len(data),backend_source_images=900,nonpositive_OpenCV_S10_conversions=int(be[(be.backend=='OpenCV_SGBM')&be.session.str.startswith('S10_')&(be.protocol=='two_anchor_heldout')].iloc[0].invalid_range_n),note='Verifies arithmetic from derived CSVs; physical ground truth and acquisition controls require independent records.')
(A/'packet_numeric_verification.json').write_text(json.dumps(report,indent=2),encoding='utf8');print(json.dumps(report,indent=2))
