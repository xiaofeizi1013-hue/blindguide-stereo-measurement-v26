from pathlib import Path
import pandas as pd,numpy as np
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch
R=Path(__file__).parent;A=R/'analysis';O=R/'figures';O.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False})
BLUE='#17659e';ORANGE='#c6532a';GREEN='#147e6c'
def save(fig,name):
 for ext in ['png','svg']:fig.savefig(O/(name+'.'+ext),dpi=400,bbox_inches='tight')
 plt.close(fig)
# A complete 2×2 ablation, including the unfavorable direct-coordinate board row.
df=pd.read_csv(A/'mapping_2x2_results.csv').set_index('estimator');fig,ax=plt.subplots(1,2,figsize=(7.2,3.0),layout='constrained')
x=np.array([0,1]);width=.32
for j,(key,label,color) in enumerate([('unmapped','Direct coordinates',ORANGE),('mapped','Remapped mask',BLUE)]):
 idx=[f'person_{key}',f'board_{key}'];pos=x+(j-.5)*width
 for k,(col,title) in enumerate([('MAPE','(a) Offset refitted for each condition'),('legacy_offset_MAPE','(b) One frozen legacy offset')]):
  vals=df.loc[idx,col].to_numpy();bars=ax[k].bar(pos,vals,width,label=label,color=color)
  ax[k].bar_label(bars,fmt='%.2f',fontsize=9,padding=2)
  ax[k].set_xticks(x,['Person core','Board core']);ax[k].set(ylabel='MAPE (%)',ylim=(0,2.55),title=title);ax[k].grid(axis='y',alpha=.2)
ax[0].legend(frameon=False,fontsize=8.5,loc='upper center',ncol=1)
save(fig,'fig2')
# Rare errors are visible next to the per-record average.
p=pd.read_csv(A/'predictions.csv');sel=p[p.protocol=='two_anchor_heldout'];fig,ax=plt.subplots(1,2,figsize=(7.2,3.05),layout='constrained')
s=sel[sel.session.str.startswith('S7_')& (sel.true_m==2.)].sort_values('seq')
ax[0].plot(s.seq,-s.signed_error_mm,'o-',color=BLUE,ms=3);ax[0].axhline(500,color=ORANGE,ls=':',label='500 mm reporting threshold');ax[0].annotate('Frame 91: 959.5 mm\nMAD 0.25 px; accepted',xy=(91,959.48),xytext=(97,690),arrowprops={'arrowstyle':'->','color':'#555555'},fontsize=9)
ax[0].set(xlabel='Recorded frame number',ylabel='Underestimation (mm)',title='(a) S7 at the nominal 2 m position',ylim=(-50,1060));ax[0].grid(alpha=.2)
for prefix,label,color in [('S4_','S4: max 935.3 mm',ORANGE),('S7_','S7: max 959.5 mm',BLUE),('S9_','S9: max 114.2 mm',GREEN)]:
 e=np.sort(abs(sel[sel.session.str.startswith(prefix)].signed_error_mm.to_numpy()));xx=np.r_[0,e];yy=np.r_[1,(len(e)-np.arange(1,len(e)+1))/len(e)];ax[1].step(xx,yy,where='post',label=label,color=color)
ax[1].set(xlabel='Absolute error threshold (mm)',ylabel='Observed fraction above threshold',title='(b) Two-anchor held-out tails',yscale='log',ylim=(.002,1.1),xlim=(0,1020));ax[1].axhline(.05,color='#777777',lw=.7,ls=':');ax[1].legend(frameon=False,fontsize=8);ax[1].grid(alpha=.2)
save(fig,'fig3')
# Independent parameterized implementation and sparse matches on the same images.
b=pd.read_csv(A/'backend_per_distance.csv');sp=pd.read_csv(A/'sources/S10_sparse.csv');s7=pd.read_csv(A/'S7_sparse.csv').set_index('seq');f=pd.read_csv(A/'backend_features.csv')
fig,ax=plt.subplots(1,2,figsize=(7.2,3.15),layout='constrained')
for backend,label,color,marker in [('libSGM','libSGM',BLUE,'o'),('OpenCV_SGBM','OpenCV SGBM',ORANGE,'s')]:
 g=b[(b.backend==backend)&b.session.str.startswith('S10')].sort_values('true_m');assert (g.n==30).all();ax[0].plot(g.true_m,g.d,marker+'-',color=color,label=label+' (30 frames/group)',ms=4)
assert (sp.groupby('true_m').size()==3).all()
ss=sp.groupby('true_m').d.median()
ax[0].scatter(sp.true_m,sp.d,s=16,facecolors='white',edgecolors=GREEN,zorder=4,label='SIFT: 3 frame medians/group')
ax[0].plot(ss.index,ss.values,'^--',color=GREEN,label='Median of 3 SIFT medians',ms=4)
ax[0].set(xlabel='Nominal board distance (m)',ylabel='Median disparity (px)',title='(a) Supported-board S10');ax[0].legend(frameon=False,fontsize=8);ax[0].grid(alpha=.2)
x=np.array([0,1]);w=.24
for j,(backend,label,color) in enumerate([('libSGM','libSGM',BLUE),('OpenCV_SGBM','OpenCV SGBM',ORANGE),('SIFT','Sparse SIFT',GREEN)]):
 vals=[float(s7.loc[seq,'d']) if backend=='SIFT' else float(f[(f.backend==backend)&f.session.str.startswith('S7_')&(f.seq==seq)].iloc[0].d) for seq in [91,92]]
 bars=ax[1].bar(x+(j-1)*w,vals,w,label=label,color=color)
 for seq,bar,value in zip([91,92],bars,vals):
  if backend=='SIFT':
   txt=f'{value:.1f}\nn={int(s7.loc[seq,"n"])}\nimage'
  else:
   row=f[(f.backend==backend)&f.session.str.startswith('S7_')&(f.seq==seq)].iloc[0]
   passed=bool(row.computable) and row.mad<=3 and row.n>=10
   txt=f'{value:.1f}\n{row.mad:.2f}\n'+('pass' if passed else 'reject')
   if not passed:bar.set_hatch('///');bar.set_edgecolor('#7c2e12')
  ax[1].text(bar.get_x()+bar.get_width()/2,value+1.0,txt,ha='center',va='bottom',fontsize=8.2,linespacing=1.12)
ax[1].set_xticks(x,['S7 frame 91','S7 frame 92']);ax[1].set(ylabel='Disparity (px)',ylim=(0,60),title='(b) Disparity / MAD / report');ax[1].grid(axis='y',alpha=.2)
save(fig,'fig4')
print('Four figures written',O)
