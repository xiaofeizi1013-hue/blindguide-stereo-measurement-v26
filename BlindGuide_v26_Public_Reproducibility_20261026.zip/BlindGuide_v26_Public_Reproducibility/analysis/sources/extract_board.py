"""Same CUDA SGM and rectification; image-only board ROI replaces person-core aggregation."""
from pathlib import Path
import ast,hashlib,json,sys,time
import cv2,numpy as np,pandas as pd
from board_localize import ROOT,DATA,OUT,NAMES,order
sys.path.insert(0,str(ROOT))
from src.stereo.sgm_match import get_matcher

cv2.setNumThreads(4)
QC=OUT/'qa';QC.mkdir(exist_ok=True)
CAL=ROOT/'configs/stereo/stereo_calib.npz'
z=np.load(CAL);size=tuple(map(int,z['image_size']))
R1,R2,P1,P2,*_=cv2.stereoRectify(z['K1'],z['D1'],z['K2'],z['D2'],size,z['R'],z['T'],alpha=0)
maps=[cv2.initUndistortRectifyMap(z[f'K{i}'],z[f'D{i}'],r,p,size,cv2.CV_32FC1) for i,r,p in [(1,R1,P1),(2,R2,P2)]]
SEEDS=json.loads((OUT/'localization_templates.json').read_text())
OVERRIDES=json.loads((OUT/'manual_seed_overrides.json').read_text())

def inner(p,fraction):
    a=(1-fraction)/2
    src=np.float32([[0,0],[1,0],[1,1],[0,1]])
    dst=np.float32([[a,a],[1-a,a],[1-a,1-a],[a,1-a]])
    return cv2.perspectiveTransform(dst.reshape(-1,1,2),cv2.getPerspectiveTransform(src,order(p))).reshape(4,2)

def stats(d,mask):
    vals=d[(mask>0)&(d>.5)]
    n=int(len(vals));area=int(np.count_nonzero(mask))
    if n<8:return dict(d=None,mad=None,n=n,area=area,valid_fraction=n/max(1,area),n_trim=0)
    med=float(np.median(vals));mad=float(np.median(np.abs(vals-med)))
    keep=vals[np.abs(vals-med)<=max(1.5,2.5*mad)] if mad>.1 else vals
    return dict(d=float(np.median(keep)),d_untrim=med,mad=mad,n=n,area=area,
                valid_fraction=n/max(1,area),n_trim=int(len(keep)),p10=float(np.percentile(vals,10)),p90=float(np.percentile(vals,90)))

def mask_poly(p):
    m=np.zeros((720,1280),np.uint8);cv2.fillConvexPoly(m,np.rint(p).astype('int32'),255);return m

def central_component(mask):
    # The wide-angle remap can produce disconnected single-pixel copies near
    # the invalid image boundary. Keep the connected board/person region.
    n,labels,components,_=cv2.connectedComponentsWithStats(mask,8)
    if n<=1:return mask,0
    selected=1+int(np.argmax(components[1:,cv2.CC_STAT_AREA]))
    clean=np.where(labels==selected,255,0).astype(np.uint8)
    return clean,int(np.count_nonzero(mask)-np.count_nonzero(clean))

def read_pair(path):
    b=path.read_bytes()
    im=cv2.imdecode(np.frombuffer(b,np.uint8),cv2.IMREAD_COLOR)
    h,w=im.shape[:2]
    assert (w,h)==(2560,960)
    return im[120:840,:1280],im[120:840,1280:],hashlib.sha256(b).hexdigest()

def crop_qc(im,mask,title,outer=None):
    ys,xs=np.where(mask>0)
    if not len(xs):return np.full((260,340,3),255,np.uint8)
    x,y=int((xs.min()+xs.max())/2),int((ys.min()+ys.max())/2)
    r=max(45,int(max(xs.max()-xs.min(),ys.max()-ys.min())*.9))
    a=im.copy()
    contours,_=cv2.findContours(mask,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
    cv2.drawContours(a,contours,-1,(0,255,0),1)
    tile=cv2.resize(a[max(0,y-r):min(720,y+r),max(0,x-r):min(1280,x+r)],(340,235))
    band=np.full((25,340,3),255,np.uint8)
    cv2.putText(band,title,(5,18),cv2.FONT_HERSHEY_SIMPLEX,.48,(0,0,0),1)
    return np.concatenate([band,tile],axis=0)

def main():
    start=time.monotonic();matcher=get_matcher(*size,max_disp=128)
    rows=[];inputs=[];qc_entries=[]
    for si,name in enumerate(NAMES,1):
        fpath=DATA/name/'features.csv';mpath=DATA/name/'manifest.csv'
        orig=pd.read_csv(fpath);orig=orig[(orig.task=='accuracy')&(orig.target=='board')].set_index('seq')
        man=pd.read_csv(mpath);man=man[(man.task=='accuracy')&(man.target=='board')].sort_values('seq')
        inputs.append(dict(session=f'S{si}',features=str(fpath),features_sha256=hashlib.sha256(fpath.read_bytes()).hexdigest(),
                           manifest_sha256=hashlib.sha256(mpath.read_bytes()).hexdigest()))
        for dist,group in man.groupby('true_m',sort=True):
            seed=next(s for s in SEEDS if s['session']==f'S{si}' and s['seq']==int(group.iloc[0].seq))
            sid=f'S{si}:{int(seed["seq"])}'
            pos=OVERRIDES.get(sid,seed['best']);poly=order(pos['p'])
            p0=None;first_gray=None;tiles=[]
            for gi,(_,record) in enumerate(group.iterrows()):
                seq=int(record.seq)
                left,right,sha=read_pair(DATA/name/'frames'/str(record.frame))
                gl=cv2.cvtColor(left,cv2.COLOR_BGR2GRAY);gr=cv2.cvtColor(right,cv2.COLOR_BGR2GRAY)
                track_status='seed';ntrack=0;fbmed=0.
                if gi==0:
                    first_gray=gl.copy()
                    p0=cv2.goodFeaturesToTrack(gl,maxCorners=220,qualityLevel=.01,minDistance=2,
                                              mask=mask_poly(inner(poly,.90)),blockSize=3)
                    first_poly=poly.copy()
                    assert p0 is not None and len(p0)>=8,(sid,'too few image features')
                else:
                    pf,ok,_=cv2.calcOpticalFlowPyrLK(first_gray,gl,p0,None,winSize=(15,15),maxLevel=3,
                                                   criteria=(cv2.TERM_CRITERIA_EPS|cv2.TERM_CRITERIA_COUNT,30,.01))
                    pb,back,_=cv2.calcOpticalFlowPyrLK(gl,first_gray,pf,None,winSize=(15,15),maxLevel=3,
                                                     criteria=(cv2.TERM_CRITERIA_EPS|cv2.TERM_CRITERIA_COUNT,30,.01))
                    fb=np.linalg.norm(pb-p0,axis=2).ravel()
                    valid=(ok.ravel()>0)&(back.ravel()>0)&(fb<.7)
                    ntrack=int(valid.sum());fbmed=float(np.median(fb[valid])) if ntrack else None
                    H,inside=(None,None)
                    if ntrack>=8:H,inside=cv2.findHomography(p0[valid],pf[valid],cv2.RANSAC,.8)
                    if H is None:poly=None;track_status='rejected_tracking'
                    else:
                        q=cv2.perspectiveTransform(first_poly.reshape(-1,1,2),H).reshape(4,2)
                        ar=abs(cv2.contourArea(q))/abs(cv2.contourArea(first_poly))
                        if not(.65<ar<1.5) or not cv2.isContourConvex(q.astype('float32')):
                            poly=None;track_status='rejected_geometry'
                        else:poly=order(q);track_status='tracked'
                rl=cv2.remap(gl,*maps[0],cv2.INTER_LINEAR);rr=cv2.remap(gr,*maps[1],cv2.INTER_LINEAR)
                d=matcher.compute(rl,rr);assert d is not None
                box=ast.literal_eval(orig.loc[seq,'box']);x1,y1,x2,y2=box;bw,bh=x2-x1,y2-y1
                # Reproduce the original integer slice exactly, for an independent backend check.
                xx1,yy1=int(max(0,x1+.22*bw)),int(max(0,y1+.22*bh))
                xx2,yy2=int(min(1280,x2-.22*bw)),int(min(720,y2-.22*bh))
                pm=np.zeros((720,1280),np.uint8);pm[yy1:yy2,xx1:xx2]=255
                old=stats(d,pm)
                ppm=cv2.remap(pm,*maps[0],cv2.INTER_NEAREST)
                ppm,person_removed=central_component(ppm)
                mapped=stats(d,ppm)
                row=dict(session=f'S{si}',session_name=name,seq=seq,true_m=float(dist),frame=str(record.frame),
                         frame_sha256=sha,seed_method=pos['method'],seed_score=seed['best']['score'],
                         track_status=track_status,track_points=ntrack,track_fb_median_px=fbmed,
                         raw_board_polygon=None if poly is None else json.dumps(poly.round(4).tolist()),
                         d_cached=float(orig.loc[seq,'d_full']),d_reproduced=old['d'],
                         d_person_mapped=mapped['d'],person_mask_removed_pixels=person_removed)
                for prefix,s in [('person_old',old),('person_mapped',mapped)]:
                    row.update({prefix+'_'+k:v for k,v in s.items()})
                masks={}
                for frac,label in [(.6,'60'),(.7,'70'),(.8,'80')]:
                    if poly is not None:
                        rawmask=mask_poly(inner(poly,frac))
                        mask=cv2.remap(rawmask,*maps[0],cv2.INTER_NEAREST)
                        mask,removed=central_component(mask)
                    else:mask=np.zeros((720,1280),np.uint8);removed=0
                    masks[label]=mask;s=stats(d,mask)
                    row.update({'board'+label+'_'+k:v for k,v in s.items()})
                    row['board'+label+'_mask_removed_pixels']=removed
                row['board70_accepted']=bool(poly is not None and row['board70_n']>=30 and row['board70_valid_fraction']>=.25)
                rows.append(row)
                if gi in [0,14,29]:
                    rim=cv2.remap(left,*maps[0],cv2.INTER_LINEAR)
                    tile=crop_qc(rim,masks['70'],f'S{si} {dist:.1f}m seq{seq} {track_status}')
                    tiles.append(tile)
                    # Full rectified frame shows person-core and board masks together.
                    if gi==14:
                        full=rim.copy()
                        contours,_=cv2.findContours(ppm,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
                        cv2.drawContours(full,contours,-1,(0,0,255),1)
                        contours,_=cv2.findContours(masks['70'],cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
                        cv2.drawContours(full,contours,-1,(0,255,0),2)
                        fn=f'S{si}_{dist:.1f}_rectified.jpg';cv2.imencode('.jpg',full)[1].tofile(str(QC/fn))
                        qc_entries.append(dict(session=f'S{si}',distance=dist,seq=seq,file=fn))
            canvas=np.concatenate(tiles,axis=1)
            cv2.imencode('.jpg',canvas)[1].tofile(str(QC/f'S{si}_{dist:.1f}_tracking.jpg'))
            pd.DataFrame(rows).to_csv(OUT/'board_features.csv',index=False,encoding='utf-8-sig')
            print(f'S{si} {dist:.1f}m complete, rows={len(rows)}, elapsed={time.monotonic()-start:.1f}s',flush=True)
    matcher.close()
    manifest=dict(date='2026-10-24',sources=inputs,calibration_sha256=hashlib.sha256(CAL.read_bytes()).hexdigest(),
                  localization_sha256=hashlib.sha256((OUT/'localization_templates.json').read_bytes()).hexdigest(),
                  overrides_sha256=hashlib.sha256((OUT/'manual_seed_overrides.json').read_bytes()).hexdigest(),
                  config=dict(sgm_max_disp=128,sgm_subpixel_scale=16,rectify_alpha=0,
                              main_mask_linear_fraction=.7,mask_sensitivity=[.6,.8],
                              minimum_valid_pixels=30,minimum_valid_fraction=.25,
                              mapped_mask_components='largest connected image region; remove isolated remap copies',
                              tracking_fb_limit_px=.7,tracking_ransac_px=.8),
                  qa_entries=qc_entries,elapsed_s=time.monotonic()-start,
                  software=dict(python=sys.version,opencv=cv2.__version__,numpy=np.__version__))
    (OUT/'extraction_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    df=pd.DataFrame(rows)
    print('Finished',len(df),'accepted',int(df.board70_accepted.sum()),
          'old max abs diff',float(np.max(np.abs(df.d_reproduced-df.d_cached))),flush=True)

if __name__=='__main__':main()
