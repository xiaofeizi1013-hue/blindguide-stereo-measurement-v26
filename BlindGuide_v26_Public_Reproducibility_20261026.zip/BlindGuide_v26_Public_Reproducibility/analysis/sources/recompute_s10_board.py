"""Recompute S10 board disparity from the manually drawn per-distance boxes."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import cv2
import numpy as np
import pandas as pd

ROOT = Path(r"D:/MIMO/blindguide/blindguide_runtime")
CALIB = ROOT / "configs/stereo/stereo_calib.npz"


class Rectify:
    def __init__(self, calib=CALIB):
        z = np.load(calib)
        self.size = tuple(int(v) for v in z["image_size"])
        R1, R2, P1, P2, *_ = cv2.stereoRectify(
            z["K1"], z["D1"], z["K2"], z["D2"], self.size, z["R"], z["T"], alpha=0)
        self.ml = cv2.initUndistortRectifyMap(z["K1"], z["D1"], R1, P1, self.size, cv2.CV_32FC1)
        self.mr = cv2.initUndistortRectifyMap(z["K2"], z["D2"], R2, P2, self.size, cv2.CV_32FC1)


def load_pair(path: Path, rect: Rectify):
    raw = cv2.imdecode(np.fromfile(str(path), np.uint8), cv2.IMREAD_COLOR)
    h, w = raw.shape[:2]
    left = raw[(h - 720) // 2:(h - 720) // 2 + 720, :w // 2]
    right = raw[(h - 720) // 2:(h - 720) // 2 + 720, w // 2:]
    gl = cv2.cvtColor(left, cv2.COLOR_BGR2GRAY)
    gr = cv2.cvtColor(right, cv2.COLOR_BGR2GRAY)
    return (cv2.remap(gl, rect.ml[0], rect.ml[1], cv2.INTER_LINEAR),
            cv2.remap(gr, rect.mr[0], rect.mr[1], cv2.INTER_LINEAR))


def stats(disp, box, inner=0.70):
    x1, y1, x2, y2 = [float(v) for v in box]
    w, h = x2 - x1, y2 - y1
    mx, my = w * (1 - inner) / 2, h * (1 - inner) / 2
    x1, x2 = int(x1 + mx), int(x2 - mx)
    y1, y2 = int(y1 + my), int(y2 - my)
    if x2 - x1 < 6 or y2 - y1 < 5:
        return dict(d=None, mad=None, n=0, area=0, valid_fraction=0.0, n_trim=0)
    patch = disp[y1:y2, x1:x2]
    vals = patch[patch > 0.5]
    n = int(vals.size)
    area = int(patch.size)
    if n < 8:
        return dict(d=None, mad=None, n=n, area=area, valid_fraction=n / max(1, area), n_trim=0)
    med = float(np.median(vals))
    mad = float(np.median(np.abs(vals - med)))
    keep = vals[np.abs(vals - med) <= max(1.5, 2.5 * mad)] if mad > 0.1 else vals
    return dict(d=float(np.median(keep)), d_untrim=med, mad=mad, n=n, area=area,
                valid_fraction=n / max(1, area), n_trim=int(len(keep)),
                p10=float(np.percentile(vals, 10)), p90=float(np.percentile(vals, 90)))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--session", required=True)
    ap.add_argument("--boxes", required=True)
    ap.add_argument("--out", default=None)
    args = ap.parse_args()
    sess = Path(args.session)
    boxes = json.loads(Path(args.boxes).read_text(encoding="utf-8"))
    man = pd.read_csv(sess / "manifest.csv")
    man = man[(man.task == "accuracy") & (man.target == "board")].sort_values("seq")
    rect = Rectify()
    sys.path.insert(0, str(ROOT))
    from src.stereo.sgm_match import get_matcher
    matcher = get_matcher(1280, 720, max_disp=128)
    rows = []
    for _, r in man.iterrows():
        key = f"{float(r.true_m):.1f}"
        if key not in boxes:
            continue
        rl, rr = load_pair(sess / "frames" / str(r.frame), rect)
        disp = matcher.compute(rl, rr)
        if disp is None:
            continue
        st = stats(disp, boxes[key])
        rows.append(dict(session=sess.name, seq=int(r.seq), true_m=float(r.true_m),
                         frame=str(r.frame), box=json.dumps(boxes[key]), **st))
    matcher.close()
    out = Path(args.out) if args.out else sess / "board_features_S10.csv"
    pd.DataFrame(rows).to_csv(out, index=False, encoding="utf-8-sig")
    df = pd.DataFrame(rows)
    print(f"wrote {out}  rows={len(df)}  accepted={int(df.d.notna().sum())}")
    print(df.groupby("true_m").agg(n=("d", "size"), d=("d", "median"),
                                    mad=("mad", "median"), area=("area", "median")).to_string())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
