from pathlib import Path
import json,ast
import cv2,numpy as np,pandas as pd
ROOT=Path('D:/MIMO/blindguide/blindguide_runtime')
DATA=ROOT/'data/sessions'
OUT=Path(__file__).parent
NAMES=['S1_20261019_2135','S2_RESET_20261024_1316','S3_RESET_20261024_1327','S4_RESET_20261024_1344','S5_RESET_20261024_1352','S6_RESET_20261024_1417']
cv2.setNumThreads(4)
DIC=cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_250)
BOARD=cv2.aruco.CharucoBoard((12,9),.03,.022,DIC)
DET=cv2.aruco.CharucoDetector(BOARD)
TEMPLATE=BOARD.generateImage((240,180),marginSize=0,borderBits=1)
TREF=cv2.GaussianBlur(TEMPLATE,(5,5),1.2).astype(float)
TREF=(TREF-TREF.mean())/TREF.std()

def load_left(name,seq):
    raw=cv2.imdecode(np.fromfile(str(DATA/name/f'frames/{seq:05}.jpg'),np.uint8),cv2.IMREAD_COLOR)
    h,w=raw.shape[:2]
    return raw[(h-720)//2:(h-720)//2+720,:w//2].copy()

def order(p):
    p=np.array(p,dtype=np.float32).reshape(-1,2)
    center=p.mean(axis=0)
    p=p[np.argsort(np.arctan2(p[:,1]-center[1],p[:,0]-center[0]))]
    p=np.roll(p,-np.argmin(p.sum(axis=1)),axis=0)
    return p

def similarity(gray,p):
    dst=np.float32([[0,0],[239,0],[239,179],[0,179]])
    H=cv2.getPerspectiveTransform(order(p),dst)
    patch=cv2.warpPerspective(gray,H,(240,180))
    patch=cv2.GaussianBlur(patch,(5,5),1.2).astype(float)
    if patch.std()<5:return -1
    patch=(patch-patch.mean())/patch.std()
    return max(float(np.mean(patch*TREF)),float(np.mean(patch*TREF[::-1,::-1])))

def candidates(img,person_box):
    gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    x1,y1,x2,y2=person_box
    bw,bh=x2-x1,y2-y1
    xa,xb=max(0,int(x1-.2*bw)),min(1280,int(x2+.2*bw))
    ya,yb=max(0,int(y1+.18*bh)),min(720,int(y2-.05*bh))
    crop=gray[ya:yb,xa:xb]
    found=[]
    # Reliable near-distance identification through decoded board corners.
    cc,ids,_,_=DET.detectBoard(gray)
    if ids is not None and len(ids)>=8:
        obj=BOARD.getChessboardCorners()[ids.ravel(),:2]
        H,good=cv2.findHomography(obj,cc,cv2.RANSAC,1.5)
        if H is not None and good.sum()>=8:
            p=order(cv2.perspectiveTransform(np.float32([[0,0],[.36,0],[.36,.27],[0,.27]]).reshape(-1,1,2),H))
            found.append(dict(p=p.tolist(),score=similarity(gray,p),method='decoded_charuco',n=int(good.sum())))
    # Geometry candidates are ranked by agreement with the known printed pattern.
    bins=[cv2.Canny(crop,40,110),cv2.Canny(crop,15,45)]
    for th in [90,120,150,180,210]:
        _,b=cv2.threshold(crop,th,255,cv2.THRESH_BINARY)
        bins.append(b)
    for bi,b in enumerate(bins):
        contours,_=cv2.findContours(b,cv2.RETR_LIST,cv2.CHAIN_APPROX_SIMPLE)
        for c in contours:
            area=cv2.contourArea(c)
            if area<250 or area>bw*bh*.9:continue
            peri=cv2.arcLength(c,True)
            for eps in [.015,.025,.04]:
                a=cv2.approxPolyDP(c,eps*peri,True)
                if len(a)!=4 or not cv2.isContourConvex(a):continue
                p=order(a.reshape(4,2)+np.array([xa,ya]))
                lens=np.linalg.norm(np.roll(p,-1,axis=0)-p,axis=1)
                ratio=(lens[0]+lens[2])/(lens[1]+lens[3])
                if not .85<ratio<2.1 or min(lens)<12:continue
                if abs(p[:,0].mean()-(x1+x2)/2)>.5*bw:continue
                for inset in [0,.025,.05,.075]:
                    q=p+(p.mean(axis=0)-p)*(2*inset)
                    score=similarity(gray,q)
                    found.append(dict(p=q.tolist(),score=score,method=f'quad_{bi}_{inset}',n=0))
                break
    return sorted(found,key=lambda v:v['score'],reverse=True)

if __name__=='__main__':
    output=[]
    for k,name in enumerate(NAMES,1):
        feat=pd.read_csv(DATA/name/'features.csv')
        tiles=[]
        for z,g in feat[(feat.task=='accuracy')&(feat.target=='board')].groupby('true_m'):
            row=g.iloc[0]; seq=int(row.seq)
            img=load_left(name,seq)
            box=ast.literal_eval(row.box)
            cand=candidates(img,box)
            best=cand[0] if cand else None
            output.append(dict(session=f'S{k}',name=name,seq=seq,true_m=z,person_box=list(box),best=best,candidates=cand[:5]))
            if best:
                p=order(best['p']);cv2.polylines(img,[p.astype('int32')],True,(0,255,0),2)
                center=p.mean(axis=0);extent=max(np.ptp(p[:,0]),np.ptp(p[:,1]))
                rad=max(50,int(extent*.65))
            else:center=np.array([(box[0]+box[2])/2,(box[1]+box[3])/2]);rad=120
            x,y=map(int,center);xa,xb=max(0,x-rad),min(1280,x+rad);ya,yb=max(0,y-rad),min(720,y+rad)
            tile=cv2.resize(img[ya:yb,xa:xb],(300,300))
            cv2.rectangle(tile,(0,0),(300,45),(255,255,255),-1)
            cv2.putText(tile,f'S{k} {z:.1f}m seq{seq}',(7,18),cv2.FONT_HERSHEY_SIMPLEX,.5,(0,0,0),1)
            cv2.putText(tile,'none' if best is None else f"score {best['score']:.2f}",(7,38),cv2.FONT_HERSHEY_SIMPLEX,.5,(0,0,0),1)
            tiles.append(tile)
            print(k,z,None if best is None else (round(best['score'],3),best['method']),flush=True)
        canvas=np.concatenate([np.concatenate(tiles[:5],axis=1),np.concatenate(tiles[5:],axis=1)],axis=0)
        cv2.imencode('.jpg',canvas)[1].tofile(str(OUT/f'localization_S{k}.jpg'))
    (OUT/'localization_candidates.json').write_text(json.dumps(output,indent=2),encoding='utf-8')
