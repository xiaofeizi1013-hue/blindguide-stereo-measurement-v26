from board_localize import *

def make_template():
    im=load_left(NAMES[3],1)
    cc,ids,_,_=DET.detectBoard(cv2.cvtColor(im,cv2.COLOR_BGR2GRAY))
    obj=BOARD.getChessboardCorners()[ids.ravel(),:2]
    H,_=cv2.findHomography(obj,cc,cv2.RANSAC,1.5)
    q=cv2.perspectiveTransform(np.float32([[0,0],[.36,0],[.36,.27],[0,.27]]).reshape(-1,1,2),H).reshape(4,2)
    M=cv2.getPerspectiveTransform(q,np.float32([[0,0],[479,0],[479,359],[0,359]]))
    return cv2.warpPerspective(cv2.cvtColor(im,cv2.COLOR_BGR2GRAY),M,(480,360))

REF=make_template()

def locate(img,box):
    gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    cc,ids,_,_=DET.detectBoard(gray)
    if ids is not None and len(ids)>=8:
        obj=BOARD.getChessboardCorners()[ids.ravel(),:2]
        H,good=cv2.findHomography(obj,cc,cv2.RANSAC,1.5)
        if H is not None and good.sum()>=8:
            p=cv2.perspectiveTransform(np.float32([[0,0],[.36,0],[.36,.27],[0,.27]]).reshape(-1,1,2),H).reshape(4,2)
            return dict(p=order(p).tolist(),score=1.0,method='decoded_charuco')
    x1,y1,x2,y2=box;bw,bh=x2-x1,y2-y1
    xa,xb=max(0,int(x1-.25*bw)),min(1280,int(x2+.25*bw))
    ya,yb=max(0,int(y1+.18*bh)),min(720,int(y2+.02*bh))
    crop=gray[ya:yb,xa:xb]
    isum,isq=cv2.integral2(crop,sdepth=cv2.CV_64F,sqdepth=cv2.CV_64F)
    best=None
    widths=np.unique(np.round(np.geomspace(max(24,bw*.4),min(560,bw*1.25),45)).astype(int))
    for width in widths:
        height=round(width*.75)
        temp=cv2.resize(REF,(int(width),height),interpolation=cv2.INTER_AREA)
        for flip in [False,True]:
            tt=temp[::-1,::-1].copy() if flip else temp
            for angle in [-10,-5,0,5,10]:
                M=cv2.getRotationMatrix2D((width/2,height/2),angle,1)
                cs=np.float32([[0,0],[width-1,0],[width-1,height-1],[0,height-1]])
                q=cv2.transform(cs[None],M)[0]
                low=q.min(axis=0); high=q.max(axis=0)
                M[:,2]-=low
                W,H=np.ceil(high-low+1).astype(int)
                if W>=crop.shape[1] or H>=crop.shape[0]:continue
                t=cv2.warpAffine(tt,M,(int(W),int(H)),borderValue=220)
                score=cv2.matchTemplate(crop,t,cv2.TM_CCOEFF_NORMED)
                total=isum[H:,W:]-isum[:-H,W:]-isum[H:,:-W]+isum[:-H,:-W]
                sqtotal=isq[H:,W:]-isq[:-H,W:]-isq[H:,:-W]+isq[:-H,:-W]
                mean=total/(W*H)
                sd=np.sqrt(np.maximum(0,sqtotal/(W*H)-mean*mean))
                score[(sd<15)|(mean<50)]=-1
                _,v,_,pos=cv2.minMaxLoc(score)
                if best is None or v>best['score']:
                    p=q-low+np.array(pos)+np.array([xa,ya])
                    best=dict(p=order(p).tolist(),score=float(v),method=f'photo_template_angle{angle}')
    return best

if __name__=='__main__':
    result=[]
    for k,name in enumerate(NAMES,1):
        feat=pd.read_csv(DATA/name/'features.csv')
        tiles=[]
        for z,g in feat[(feat.task=='accuracy')&(feat.target=='board')].groupby('true_m'):
            row=g.iloc[0]; seq=int(row.seq);im=load_left(name,seq);box=ast.literal_eval(row.box)
            best=locate(im,box)
            result.append(dict(session=f'S{k}',name=name,seq=seq,true_m=float(z),best=best))
            p=order(best['p']);cv2.polylines(im,[p.astype('int32')],True,(0,255,0),2)
            x,y=p.mean(axis=0).astype(int);r=max(45,int(max(np.ptp(p[:,0]),np.ptp(p[:,1]))*.7))
            xa,xb=max(0,x-r),min(1280,x+r);ya,yb=max(0,y-r),min(720,y+r)
            tile=cv2.resize(im[ya:yb,xa:xb],(300,300))
            cv2.rectangle(tile,(0,0),(300,45),(255,255,255),-1)
            cv2.putText(tile,f'S{k} {z:.1f}m seq{seq}',(7,18),cv2.FONT_HERSHEY_SIMPLEX,.5,(0,0,0),1)
            cv2.putText(tile,f"score {best['score']:.2f}",(7,38),cv2.FONT_HERSHEY_SIMPLEX,.5,(0,0,0),1)
            tiles.append(tile)
            print(k,z,round(best['score'],3),flush=True)
        canvas=np.concatenate([np.concatenate(tiles[:5],axis=1),np.concatenate(tiles[5:],axis=1)],axis=0)
        cv2.imencode('.jpg',canvas)[1].tofile(str(OUT/f'template_S{k}.jpg'))
        (OUT/'localization_templates.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
