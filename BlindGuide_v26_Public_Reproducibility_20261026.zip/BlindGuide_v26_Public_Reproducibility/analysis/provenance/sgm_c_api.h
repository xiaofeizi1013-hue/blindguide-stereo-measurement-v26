#pragma once
#ifdef _WIN32
#define SGM_API __declspec(dllexport)
#else
#define SGM_API
#endif
#ifdef __cplusplus
extern "C" {
#endif
SGM_API int sgm_compute(const unsigned char* left, const unsigned char* right,
                int width, int height, int max_disp, short* disp);
SGM_API void sgm_shutdown();
#ifdef __cplusplus
}
#endif
