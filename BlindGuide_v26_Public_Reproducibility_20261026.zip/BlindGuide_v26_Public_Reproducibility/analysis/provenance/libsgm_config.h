#ifndef __LIBSGM_CONFIG_H__
#define __LIBSGM_CONFIG_H__

/* #undef LIBSGM_SHARED */

#define LIBSGM_VERSION 3.1.0
#define LIBSGM_VERSION_MAJOR 3
#define LIBSGM_VERSION_MINOR 1
#define LIBSGM_VERSION_PATCH 0

/* #undef BUILD_OPENCV_WRAPPER */

#endif // __LIBSGM_CONFIG_H__
