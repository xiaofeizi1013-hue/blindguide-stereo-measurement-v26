#include "sgm_c_api.h"
#include "libsgm.h"

static sgm::StereoSGM* g_sgm = nullptr;
static int g_w = 0, g_h = 0, g_d = 0;

extern "C" int sgm_compute(const unsigned char* left, const unsigned char* right,
                           int width, int height, int max_disp, short* disp) {
    if (!left || !right || !disp) return -1;
    // disparity_size ??? 64/128/256
    int ds = 128;
    if (max_disp <= 64) ds = 64;
    else if (max_disp > 128) ds = 256;
    if (!g_sgm || g_w != width || g_h != height || g_d != ds) {
        delete g_sgm;
        sgm::StereoSGM::Parameters p(10, 120, 0.95f, true,
                                     sgm::PathType::SCAN_8PATH,
                                     0, 1,
                                     sgm::CensusType::SYMMETRIC_CENSUS_9x7);
        // subpixel=true ? 16bit ??, ??16
        g_sgm = new sgm::StereoSGM(width, height, ds, 8, 16,
                                   sgm::EXECUTE_INOUT_HOST2HOST, p);
        g_w = width; g_h = height; g_d = ds;
    }
    g_sgm->execute(left, right, disp);
    return 0;
}

extern "C" void sgm_shutdown() {
    delete g_sgm; g_sgm = nullptr; g_w = g_h = g_d = 0;
}


