"""libSGM CUDA 立体匹配 Python 绑定（ctypes）。

用法:
    from src.stereo.sgm_match import SgmMatcher
    m = SgmMatcher(width=1280, height=720, max_disp=128)
    disp = m.compute(left_gray, right_gray)   # np.int16, 值=视差×16 (subpixel)
"""
from __future__ import annotations

import ctypes
import os
from pathlib import Path
from typing import Optional, Tuple

import numpy as np

# 默认使用仓库内对应平台的 libSGM；可用环境变量 SGM_LIB_PATH 覆盖
_LIB_NAME = "sgm_c_api.dll" if os.name == "nt" else "sgm_c_api.so"
_DEFAULT_LIB = Path(__file__).resolve().parents[2] / "libSGM" / "dist" / _LIB_NAME
_LIB_PATH = Path(os.environ.get("SGM_LIB_PATH", _DEFAULT_LIB))
_lib = None


def _load():
    global _lib
    if _lib is None:
        if not _LIB_PATH.exists():
            raise FileNotFoundError(f"libSGM 动态库未找到: {_LIB_PATH}")
        _lib = ctypes.CDLL(str(_LIB_PATH))
        _lib.sgm_compute.argtypes = [
            ctypes.POINTER(ctypes.c_ubyte),
            ctypes.POINTER(ctypes.c_ubyte),
            ctypes.c_int, ctypes.c_int, ctypes.c_int,
            ctypes.POINTER(ctypes.c_short),
        ]
        _lib.sgm_compute.restype = ctypes.c_int
        _lib.sgm_shutdown.argtypes = []
        _lib.sgm_shutdown.restype = None
    return _lib


class SgmMatcher:
    """CUDA SGM 稠密视差。subpixel=True 时输出 d×16。"""

    def __init__(self, width: int, height: int, max_disp: int = 128, subpixel_scale: int = 16):
        self.w = width
        self.h = height
        self.max_disp = max_disp
        self.scale = subpixel_scale
        self._lib = _load()
        self._disp = np.zeros((height, width), dtype=np.int16)

    def compute(self, left_gray: np.ndarray, right_gray: np.ndarray) -> Optional[np.ndarray]:
        """返回视差图 (float32, 像素单位)。失败返回 None。"""
        if left_gray is None or right_gray is None:
            return None
        if left_gray.shape[:2] != (self.h, self.w):
            # 自适应尺寸
            self.h, self.w = left_gray.shape[:2]
            self._disp = np.zeros((self.h, self.w), dtype=np.int16)
        lg = np.ascontiguousarray(left_gray, dtype=np.uint8)
        rg = np.ascontiguousarray(right_gray, dtype=np.uint8)
        if lg.shape != rg.shape:
            return None
        ptr_l = lg.ctypes.data_as(ctypes.POINTER(ctypes.c_ubyte))
        ptr_r = rg.ctypes.data_as(ctypes.POINTER(ctypes.c_ubyte))
        ptr_d = self._disp.ctypes.data_as(ctypes.POINTER(ctypes.c_short))
        rc = self._lib.sgm_compute(ptr_l, ptr_r, self.w, self.h, self.max_disp, ptr_d)
        if rc != 0:
            return None
        return self._disp.astype(np.float32) / float(self.scale)

    def close(self):
        try:
            self._lib.sgm_shutdown()
        except Exception:
            pass


# 帧级复用的默认匹配器（同尺寸热更新，尺寸变化自动重建）
_default_matcher: Optional[SgmMatcher] = None


def get_matcher(width: int, height: int, max_disp: int = 128) -> SgmMatcher:
    global _default_matcher
    if _default_matcher is None:
        _default_matcher = SgmMatcher(width, height, max_disp=max_disp)
    elif _default_matcher.w != width or _default_matcher.h != height:
        _default_matcher.close()
        _default_matcher = SgmMatcher(width, height, max_disp=max_disp)
    return _default_matcher


def match_box_sgm(
    disp: np.ndarray,
    box: Tuple[float, float, float, float],
    margin: float = 0.22,
    strip_frac: float = 0.18,
    min_valid: int = 15,
    max_std_px: float = 2.5,
) -> Optional[Tuple[float, float]]:
    """从稠密视差图取框核心区视差。接口对齐 ncc_match.match_box_core。

    返回 (d_median, score) 或 None。score≈有效像素比例。
    """
    x1, y1, x2, y2 = box
    w, h = x2 - x1, y2 - y1
    if w < 20 or h < 16 or disp is None:
        return None
    mx, my = w * margin, h * margin
    cx1, cy1 = int(x1 + mx), int(y1 + my)
    cx2, cy2 = int(x2 - mx), int(y2 - my)
    H, W = disp.shape[:2]
    cx1, cy1 = max(0, cx1), max(0, cy1)
    cx2, cy2 = min(W, cx2), min(H, cy2)
    if cx2 - cx1 < 8 or cy2 - cy1 < 8:
        return None
    patch = disp[cy1:cy2, cx1:cx2]
    # 底边条带优先（近处/接地），不足则用核心区
    sh = max(6, int((cy2 - cy1) * strip_frac))
    strip = patch[-sh:, :]
    vals = strip[strip > 0.5]
    if vals.size < min_valid:
        vals = patch[patch > 0.5]
    if vals.size < min_valid:
        return None
    med = float(np.median(vals))
    std = float(np.std(vals))
    if std > max_std_px:
        return None
    score = float(min(1.0, vals.size / max(1, patch.size) * 3.0))
    return med, score
