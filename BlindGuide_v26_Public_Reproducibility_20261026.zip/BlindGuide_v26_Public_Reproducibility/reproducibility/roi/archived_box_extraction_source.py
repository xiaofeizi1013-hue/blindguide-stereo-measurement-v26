"""E-ALL 离线分析：从 e_all_record.py 录的原始帧算出论文用表和图。

输入：data/sessions/<name>/（manifest.csv + frames/ + session.json）
输出：会话目录下
    features.csv          每帧的原始测量量（d/n_valid/mad/各方法视差）
    table1_accuracy.csv       测距精度（全帧）
    table1b_accuracy_roi.csv  测距精度（旧 ROI 320 画布）
    table1c_accuracy_roi_v2.csv 测距精度（新 ROI v2）
    table_path_compare.csv    三条路径总账（精度 + 计算当量）
    table2_ablation.csv       同帧消融
    table3_stability.csv      静态 + 走入时序
    table4_reject.csv         拒识-误差曲线
    e0_fb_fit.csv / e0_fb_fit_by_target.csv
    fig_*.png, summary.md

用法
----
    python scripts/e_all_analyze.py --session data/sessions/S1_xxx
    python scripts/e_all_analyze.py --all
    python scripts/e_all_analyze.py --all --write-scale
    python scripts/e_all_analyze.py --all --no-cache --box center
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path

import cv2
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.stereo import roi as roi_v2_mod  # noqa: E402
from src.stereo.ncc_match import match_box_core  # noqa: E402
from src.stereo.roi import FULL_WORK, plan as roi_v2_plan  # noqa: E402
from src.stereo.scale import calib_fb, load as load_scale, save_fit  # noqa: E402
from src.stereo.sgm_match import SgmMatcher, get_matcher  # noqa: E402

CALIB = ROOT / "configs" / "stereo" / "stereo_calib.npz"
SESSIONS = ROOT / "data" / "sessions"
K_EMPIRICAL = 19704.4
TARGET_HEIGHT = {"person": 1.70, "board": 0.27, "wall": 1.20, "other": 1.50}
ROI_SIZE, ROI_MAX_DISP, ROI_CROP_MAX = 320, 128, 480
BASELINE_MM = 66.43456099033814


# ---------------------------------------------------------------------------
# 会话与几何
# ---------------------------------------------------------------------------
def list_sessions(arg_all: bool, paths: list) -> list:
    out = []
    for p in paths:
        d = Path(p)
        if not d.is_absolute():
            d = ROOT / p
        if (d / "manifest.csv").exists():
            out.append(d)
    if arg_all:
        out += [d for d in sorted(SESSIONS.glob("*")) if (d / "manifest.csv").exists()]
    seen, uniq = set(), []
    for d in out:
        if d.name not in seen:
            seen.add(d.name)
            uniq.append(d)
    return uniq


def center_crop(img, out_w, out_h):
    h, w = img.shape[:2]
    if w == out_w and h == out_h:
        return img
    if w >= out_w and h >= out_h:
        return img[(h - out_h) // 2:(h - out_h) // 2 + out_h,
                   (w - out_w) // 2:(w - out_w) // 2 + out_w]
    scale = min(out_w / w, out_h / h)
    nw, nh = int(round(w * scale)), int(round(h * scale))
    canvas = np.zeros((out_h, out_w) if img.ndim == 2 else (out_h, out_w, img.shape[2]), img.dtype)
    canvas[(out_h - nh) // 2:(out_h - nh) // 2 + nh,
           (out_w - nw) // 2:(out_w - nw) // 2 + nw] = cv2.resize(img, (nw, nh),
                                                                 interpolation=cv2.INTER_AREA)
    return canvas


def split_frame(raw, stereo_size, work_size):
    h, w = raw.shape[:2]
    sw, sh = stereo_size
    ww, wh = work_size
    if (w, h) == (sw, sh) or w >= 2 * ww:
        half = w // 2
        return center_crop(raw[:, :half], ww, wh), center_crop(raw[:, half:], ww, wh)
    return raw, None


class Rectify:
    def __init__(self, calib_path=CALIB):
        z = np.load(calib_path)
        self.size = tuple(int(v) for v in z["image_size"])
        R1, R2, P1, P2, _, _, _ = cv2.stereoRectify(
            z["K1"], z["D1"], z["K2"], z["D2"], self.size, z["R"], z["T"], alpha=0)
        self.ml = cv2.initUndistortRectifyMap(z["K1"], z["D1"], R1, P1, self.size, cv2.CV_32FC1)
        self.mr = cv2.initUndistortRectifyMap(z["K2"], z["D2"], R2, P2, self.size, cv2.CV_32FC1)
        self.f_px_rect = float(P1[0, 0])

    def __call__(self, gl, gr):
        if (gl.shape[1], gl.shape[0]) != self.size:
            return gl, gr, False
        return (cv2.remap(gl, self.ml[0], self.ml[1], cv2.INTER_LINEAR),
                cv2.remap(gr, self.mr[0], self.mr[1], cv2.INTER_LINEAR), True)


# ---------------------------------------------------------------------------
# 框与视差
# ---------------------------------------------------------------------------
def resolve_box(mode, img, work_size, model, conf=0.35):
    W, H = work_size
    center = (int(W * 0.28), int(H * 0.18), int(W * 0.72), int(H * 0.82))
    if mode == "center" or model is None:
        return center, "center"
    r = model.predict(img, imgsz=640, conf=conf, verbose=False, half=True, classes=[0])[0]
    best, bd = None, 1e9
    if r.boxes is not None and len(r.boxes):
        for b in r.boxes:
            x1, y1, x2, y2 = [int(v) for v in b.xyxy[0].tolist()]
            bw, bh = x2 - x1, y2 - y1
            if bw < 20 or bh < 20 or bw * bh > 0.9 * W * H:
                continue
            dd = abs((x1 + x2) / 2 - W / 2) + abs((y1 + y2) / 2 - H / 2)
            if dd < bd:
                bd, best = dd, (x1, y1, x2, y2)
    if best is None and mode == "auto":
        return center, "center"
    return (best, "yolo") if best else (center, "center")


def box_stats(disp, box, margin=0.22):
    """框核心区视差中位数 + 有效像素数 + MAD（与 releases/A3-v 口径一致）。"""
    if disp is None:
        return None, 0, None
    x1, y1, x2, y2 = [float(v) for v in box]
    w, h = x2 - x1, y2 - y1
    if w < 16 or h < 12:
        return None, 0, None
    mx, my = w * margin, h * margin
    ix1, iy1 = int(max(0, x1 + mx)), int(max(0, y1 + my))
    ix2, iy2 = int(min(disp.shape[1], x2 - mx)), int(min(disp.shape[0], y2 - my))
    if ix2 - ix1 < 8 or iy2 - iy1 < 8:
        return None, 0, None
    patch = disp[iy1:iy2, ix1:ix2]
    vals = patch[patch > 0.5]
    n = int(vals.size)
    if n < 8:
        return None, n, None
    med = float(np.median(vals))
    mad = float(np.median(np.abs(vals - med)))
    if mad > 0.1:
        keep = vals[np.abs(vals - med) <= max(1.5, 2.5 * mad)]
        if keep.size < 8:
            return None, n, mad
        med = float(np.median(keep))
    return med, n, mad


def roi_disp_old(gl_raw, gr_raw, box, matcher, rect: Rectify, margin=0.18):
    """旧 ROI 路径（复刻 demo 原始实现：裁框 → 缩到 320 画布 → 补偿 scale）。"""
    x1, y1, x2, y2 = [float(v) for v in box]
    w, h = x2 - x1, y2 - y1
    if w < 24 or h < 24:
        return None, None
    cx, cy = (x1 + x2) * 0.5, (y1 + y2) * 0.5
    hw = min(w * (0.5 + margin), ROI_CROP_MAX * 0.5)
    hh = min(h * (0.5 + margin), ROI_CROP_MAX * 0.5)
    X1 = int(max(0, cx - hw)); X2 = int(min(gl_raw.shape[1], cx + hw))
    Y1 = int(max(0, cy - hh)); Y2 = int(min(gl_raw.shape[0], cy + hh))
    if X2 - X1 < 24 or Y2 - Y1 < 24:
        return None, None
    if (gl_raw.shape[1], gl_raw.shape[0]) == rect.size:
        L = cv2.remap(gl_raw[Y1:Y2, X1:X2], rect.ml[0][Y1:Y2, X1:X2] - X1,
                      rect.ml[1][Y1:Y2, X1:X2] - Y1, cv2.INTER_LINEAR)
        R = cv2.remap(gr_raw[Y1:Y2, X1:X2], rect.mr[0][Y1:Y2, X1:X2] - X1,
                      rect.mr[1][Y1:Y2, X1:X2] - Y1, cv2.INTER_LINEAR)
    else:
        L, R = gl_raw[Y1:Y2, X1:X2], gr_raw[Y1:Y2, X1:X2]
    rh, rw = L.shape[:2]
    scale = min(1.0, ROI_SIZE / max(rw, rh))
    nw = max(8, int(round(rw * scale))); nh = max(8, int(round(rh * scale)))
    if (nw, nh) != (rw, rh):
        L = cv2.resize(L, (nw, nh), interpolation=cv2.INTER_AREA)
        R = cv2.resize(R, (nw, nh), interpolation=cv2.INTER_AREA)
    cl = np.zeros((ROI_SIZE, ROI_SIZE), np.uint8)
    cr = np.zeros((ROI_SIZE, ROI_SIZE), np.uint8)
    ox, oy = (ROI_SIZE - nw) // 2, (ROI_SIZE - nh) // 2
    cl[oy:oy + nh, ox:ox + nw] = L
    cr[oy:oy + nh, ox:ox + nw] = R
    dmap = matcher.compute(cl, cr)
    if dmap is None:
        return None, scale
    mx, my = int(nw * 0.22), int(nh * 0.22)
    patch = dmap[oy + my:oy + nh - my, ox + mx:ox + nw - mx]
    vals = patch[(patch > 0.5) & (patch < ROI_MAX_DISP)]
    if vals.size < 20:
        return None, scale
    return float(np.median(vals)) / max(scale, 1e-6), scale


def roi_disp_v2(gl_raw, gr_raw, box, rect, matchers, fb, baseline_mm, target_h=1.70):
    """委托给 src/stereo/roi.py（与 demo 共用同一实现）。"""
    return roi_v2_mod.match(gl_raw, gr_raw, box, (rect.ml, rect.mr), matchers,
                            fb, baseline_mm, target_h=target_h, calib_size=rect.size)


# ---------------------------------------------------------------------------
# 特征抽取（缓存只存原始测量量，Z 每次按当前口径重算）
# ---------------------------------------------------------------------------
RAW_COLS = ["session", "seq", "task", "tag", "target", "true_m", "box", "box_src",
            "box_h", "rectified", "d_full", "n_full", "mad_full", "d_roi", "scale_roi",
            "d_ncc", "d_roi2", "roi2_max_disp", "roi2_win_w", "roi2_win_h", "roi2_ratio"]


def _add_zs(df, fb_mm_px, disp_offset_px):
    df["fb_mm_px"] = fb_mm_px
    df["disp_offset_px"] = disp_offset_px

    def z_of(d, sc=1.0):
        if d is None or pd.isna(d) or d <= 0.5:
            return None
        den = float(d) + float(disp_offset_px) * float(sc or 1.0)
        return None if den <= 0.5 else fb_mm_px * float(sc or 1.0) / den / 1000.0

    df["z_full"] = df["d_full"].apply(lambda v: z_of(v))
    df["z_roi"] = df.apply(lambda r: z_of(r["d_roi"], r["scale_roi"] or 1.0), axis=1)
    df["z_roi2"] = df["d_roi2"].apply(lambda v: z_of(v)) if "d_roi2" in df else None
    df["z_ncc_k"] = K_EMPIRICAL / df["d_ncc"] / 1000.0
    df["z_ncc_fb"] = df["d_ncc"].apply(lambda v: z_of(v))

    def prior(r):
        h = r["box_h"]
        if not h or h < 20 or pd.isna(h):
            return None
        H = TARGET_HEIGHT.get(str(r["target"]), 1.5)
        return fb_mm_px / BASELINE_MM * H / h

    df["z_prior"] = df.apply(prior, axis=1)
    return df


def extract_features(sessions, box_mode, fb_mm_px, disp_offset_px=0.0, cache=True,
                     max_frames=None, verbose=True):
    rect = Rectify()
    model = None
    if box_mode in ("yolo", "auto"):
        from ultralytics import YOLO
        model = YOLO(str(ROOT / "yolov8s.pt"))
    m_full = get_matcher(rect.size[0], rect.size[1], max_disp=128)
    m_old = SgmMatcher(ROI_SIZE, ROI_SIZE, max_disp=ROI_MAX_DISP)
    m_v2 = {}
    out = []

    for sd in sessions:
        meta = json.loads((sd / "session.json").read_text(encoding="utf-8")) \
            if (sd / "session.json").exists() else {}
        man = pd.read_csv(sd / "manifest.csv")
        if max_frames:
            man = man.groupby(["task", "true_m"], dropna=False).head(max_frames)
        cache_p = sd / "features.csv"
        if cache and cache_p.exists() and \
                cache_p.stat().st_mtime >= (sd / "manifest.csv").stat().st_mtime:
            df = pd.read_csv(cache_p)
            need = {"d_roi2", "d_full", "n_full", "mad_full"}
            if need.issubset(df.columns) and len(df) >= len(man):
                df = df[[c for c in df.columns if c in RAW_COLS]]
                _add_zs(df, fb_mm_px, disp_offset_px)
                if verbose:
                    print(f"[cache] {sd.name}: {len(df)} 帧（Z 按当前口径重算）")
                out.append(df)
                continue

        stereo = tuple(meta.get("stereo_size", [2560, 960]))
        work = tuple(meta.get("work_size", [1280, 720]))
        recs = []
        for _, row in man.iterrows():
            fp = sd / "frames" / str(row["frame"])
            raw = cv2.imdecode(np.fromfile(str(fp), np.uint8), cv2.IMREAD_COLOR) \
                if fp.exists() else None
            if raw is None:
                continue
            left, right = split_frame(raw, stereo, work)
            if right is None:
                continue
            gl = cv2.cvtColor(left, cv2.COLOR_BGR2GRAY)
            gr = cv2.cvtColor(right, cv2.COLOR_BGR2GRAY)
            rl, rr, did_rect = rect(gl, gr)
            disp = m_full.compute(rl, rr)
            box, bsrc = resolve_box(box_mode, left, (gl.shape[1], gl.shape[0]), model)
            d_full, n_full, mad_full = box_stats(disp, box)
            d_old, sc_old = roi_disp_old(gl, gr, box, m_old, rect)
            d_v2, info_v2 = roi_disp_v2(gl, gr, box, rect, m_v2, fb_mm_px, BASELINE_MM,
                                        target_h=1.70)
            ncc = match_box_core(rl, rr, box, max_disp=96, n_rows=7, min_votes=3)
            d_ncc = float(ncc[0]) if ncc and ncc[0] else None
            win = info_v2.get("win") or (0, 0, 0, 0)
            recs.append({
                "session": sd.name, "seq": int(row["seq"]), "task": row["task"],
                "tag": row.get("tag", ""), "target": row.get("target", ""),
                "true_m": row["true_m"], "box": str(tuple(int(v) for v in box)),
                "box_src": bsrc, "box_h": float(box[3] - box[1]), "rectified": did_rect,
                "d_full": d_full, "n_full": n_full, "mad_full": mad_full,
                "d_roi": d_old, "scale_roi": sc_old, "d_ncc": d_ncc,
                "d_roi2": d_v2, "roi2_max_disp": info_v2.get("max_disp"),
                "roi2_win_w": (win[2] - win[0]) or None, "roi2_win_h": (win[3] - win[1]) or None,
                "roi2_ratio": info_v2.get("ratio"),
            })
            if verbose and len(recs) % 200 == 0:
                print(f"  ... {sd.name} {len(recs)} 帧", flush=True)
        df = pd.DataFrame(recs)
        if df.empty:
            continue
        _add_zs(df, fb_mm_px, disp_offset_px)
        if cache:
            df.to_csv(cache_p, index=False, encoding="utf-8")
        if verbose:
            print(f"[done ] {sd.name}: {len(df)} 帧" +
                  ("" if df["rectified"].any() else "  (尺寸≠标定，按已校正处理)"))
        out.append(df)

    m_full.close()
    m_old.close()
    return pd.concat(out, ignore_index=True) if out else pd.DataFrame()


# ---------------------------------------------------------------------------
# 表
# ---------------------------------------------------------------------------
def tbl_accuracy(df, col, fb):
    d = df[(df["task"].isin(["accuracy", "hard"])) & df["true_m"].notna()].copy()
    if d.empty or col not in d:
        return pd.DataFrame()
    d["true_m"] = d["true_m"].astype(float)
    rows = []
    for (tg, tm), g in d.groupby(["target", "true_m"]):
        z = g[col].dropna()
        n_all, n_ok = len(g), len(z)
        if n_ok == 0:
            rows.append(dict(target=tg, true_m=tm, n=n_all, n_ok=0, fail_pct=100.0))
            continue
        tru = g.loc[z.index, "true_m"].values
        err = np.abs(z.values - tru)
        rows.append(dict(
            target=tg, true_m=tm, n=n_all, n_ok=n_ok,
            fail_pct=round(100 * (1 - n_ok / n_all), 1),
            mean_z=round(float(z.mean()), 4), std_m=round(float(z.std()), 4),
            bias_m=round(float(np.mean(z.values - tru)), 4),
            mae_mm=round(float(err.mean()) * 1000, 1),
            p95_mm=round(float(np.percentile(err, 95)) * 1000, 1),
            mape_pct=round(float(np.mean(err / tru)) * 100, 1),
        ))
    return pd.DataFrame(rows).sort_values(["target", "true_m"]).reset_index(drop=True)


def tbl_path_compare(df, fb):
    """三条测距路径总账：精度 + 拒识率 + 计算当量（Jetson 预算用）。"""
    d = df[(df["task"].isin(["accuracy", "hard"])) & df["true_m"].notna()].copy()
    if d.empty:
        return pd.DataFrame()
    d["true_m"] = d["true_m"].astype(float)
    rows = []

    def add(name, zcol, ratio):
        if zcol not in d or d[zcol].dropna().empty:
            rows.append(dict(path=name, n=len(d), n_ok=0, fail_pct=100.0, mape_pct=None,
                             p95_mm=None, bias_mm=None, work_ratio=round(ratio, 4)))
            return
        z = d[zcol].dropna()
        tru = d.loc[z.index, "true_m"].values
        err = np.abs(z.values - tru)
        rows.append(dict(
            path=name, n=len(d), n_ok=len(z),
            fail_pct=round(100 * (1 - len(z) / len(d)), 1),
            mape_pct=round(float(np.mean(err / tru)) * 100, 2),
            p95_mm=round(float(np.percentile(err, 95)) * 1000, 1),
            bias_mm=round(float(np.mean(z.values - tru)) * 1000, 1),
            work_ratio=round(ratio, 4),
        ))

    add("full_frame_1280x720@128", "z_full", 1.0)
    add("old_roi_320@128", "z_roi", (ROI_SIZE * ROI_SIZE * ROI_MAX_DISP) / FULL_WORK)
    r_v2 = (float(df["roi2_ratio"].dropna().median())
            if "roi2_ratio" in df and df["roi2_ratio"].notna().any() else 0.0)
    add("v2_roi_native_adaptive", "z_roi2", r_v2)
    out = pd.DataFrame(rows)
    out.attrs["ratio_p95"] = (round(float(df["roi2_ratio"].quantile(0.95)), 4)
                              if "roi2_ratio" in df and df["roi2_ratio"].notna().any() else None)
    out.attrs["maxdisp_med"] = (float(df["roi2_max_disp"].median())
                                if "roi2_max_disp" in df and df["roi2_max_disp"].notna().any()
                                else None)
    out.attrs["win_med"] = ((float(df["roi2_win_w"].median()), float(df["roi2_win_h"].median()))
                            if "roi2_win_w" in df and df["roi2_win_w"].notna().any() else None)
    return out


def tbl_ablation(df, fb):
    d = df[(df["task"].isin(["accuracy", "hard"])) & df["true_m"].notna()].copy()
    if d.empty:
        return pd.DataFrame()
    d["true_m"] = d["true_m"].astype(float)
    methods = [("A_sgm_fb", "z_full"), ("B_ncc_k", "z_ncc_k"),
               ("C_zp_only", "z_prior"), ("D_ncc_fb", "z_ncc_fb")]
    rows = []
    for (tg, tm), g in d.groupby(["target", "true_m"]):
        for name, col in methods:
            z = g[col].dropna()
            if len(z) == 0:
                rows.append(dict(target=tg, true_m=tm, method=name, n=len(g), n_ok=0,
                                 fail_pct=100.0))
                continue
            tru = g.loc[z.index, "true_m"].values
            err = np.abs(z.values - tru)
            rows.append(dict(
                target=tg, true_m=tm, method=name, n=len(g), n_ok=len(z),
                fail_pct=round(100 * (1 - len(z) / len(g)), 1),
                mean_z=round(float(z.mean()), 4),
                bias_mm=round(float(np.mean(z.values - tru)) * 1000, 1),
                mae_mm=round(float(err.mean()) * 1000, 1),
                p95_mm=round(float(np.percentile(err, 95)) * 1000, 1),
            ))
    return pd.DataFrame(rows).sort_values(["target", "true_m", "method"]).reset_index(drop=True)


def _ema(x, alpha_old=0.55):
    s, out = None, []
    for v in x:
        s = float(v) if s is None else alpha_old * s + (1.0 - alpha_old) * float(v)
        out.append(s)
    return np.asarray(out)


def tbl_stability(df, ema_alpha=0.55):
    rows = []
    for (sess, task), g in df.groupby(["session", "task"]):
        if task not in ("static", "walk"):
            continue
        z = g.sort_values("seq")["z_full"].dropna().values
        if len(z) < 5:
            continue
        ze = _ema(z, ema_alpha)
        dz, dze = np.abs(np.diff(z)), np.abs(np.diff(ze))
        row = dict(session=sess, task=task, n=len(z), mean_m=round(float(z.mean()), 3),
                   std_mm=round(float(z.std()) * 1000, 1),
                   span_mm=round(float(z.max() - z.min()) * 1000, 1),
                   max_step_mm=round(float(dz.max()) * 1000, 1),
                   n_jump_50mm=int((dz > 0.050).sum()),
                   ema_std_mm=round(float(ze.std()) * 1000, 1),
                   ema_span_mm=round(float(ze.max() - ze.min()) * 1000, 1),
                   ema_max_step_mm=round(float(dze.max()) * 1000, 1),
                   ema_n_jump_50mm=int((dze > 0.050).sum()))
        if task == "walk":
            row["monotonic_pct"] = round(float(np.mean(np.diff(z) < 0)) * 100, 1)
            row["ema_monotonic_pct"] = round(float(np.mean(np.diff(ze) < 0)) * 100, 1)
            row["ema_median_step_mm"] = round(float(np.median(dze)) * 1000, 1)
            row["start_m"] = round(float(ze[0]), 3)
            row["end_m"] = round(float(ze[-1]), 3)
        rows.append(row)
    return pd.DataFrame(rows)


def tbl_reject(df, min_valids=(8, 20, 50, 100, 200), max_mads=(0.2, 0.5, 1.0, 2.0, 5.0)):
    d = df[(df["task"].isin(["accuracy", "hard"])) & df["true_m"].notna()].copy()
    if d.empty:
        return pd.DataFrame()
    d["true_m"] = d["true_m"].astype(float)
    d = d[d["d_full"].notna() | d["n_full"].notna()]
    rows = []
    for mv in min_valids:
        for mm in max_mads:
            ok = d[(d["n_full"] >= mv) & (d["mad_full"].fillna(99.0) <= mm) & d["z_full"].notna()]
            if len(ok) == 0:
                rows.append(dict(min_valid=mv, max_mad=mm, coverage=0.0, n_delivered=0,
                                 p95_mm=None, mae_mm=None))
                continue
            err = np.abs(ok["z_full"].values - ok["true_m"].values)
            rows.append(dict(min_valid=mv, max_mad=mm,
                             coverage=round(len(ok) / max(1, len(d)), 3),
                             n_delivered=len(ok),
                             p95_mm=round(float(np.percentile(err, 95)) * 1000, 1),
                             mae_mm=round(float(err.mean()) * 1000, 1)))
    ok = d[d["z_full"].notna()]
    if len(ok):
        err = np.abs(ok["z_full"].values - ok["true_m"].values)
        rows.append(dict(min_valid=0, max_mad=999.0, coverage=round(len(ok) / len(d), 3),
                         n_delivered=len(ok),
                         p95_mm=round(float(np.percentile(err, 95)) * 1000, 1),
                         mae_mm=round(float(err.mean()) * 1000, 1)))
    return pd.DataFrame(rows)


def fit_by_target(df):
    """分目标各自拟合 (fB, 零偏)。

    尺度基准应取平面目标：人体可见面随姿势浮动 5-10 cm，会把 fB 拉偏
    （实测：仅板 46.1k vs 合并 43.0k）。
    """
    d = df[(df["task"].isin(["accuracy", "hard"])) & df["true_m"].notna()
           & df["d_full"].notna()].copy()
    if d.empty:
        return pd.DataFrame()
    d["true_m"] = d["true_m"].astype(float)
    rows = []
    for tg, g in d.groupby("target"):
        Z = g["true_m"].values.astype(float)
        D = g["d_full"].values.astype(float)
        A = np.stack([1.0 / (Z * 1000.0), np.ones_like(Z)], axis=1)
        (fb, d0), *_ = np.linalg.lstsq(A, D, rcond=None)
        off = -float(d0)
        zp = fb / (D + off) / 1000.0
        rows.append(dict(target=tg, n=len(Z), n_dist=int(len(set(Z))),
                         fb_fit=round(float(fb), 0), offset_px=round(off, 2),
                         rms_px=round(float(np.sqrt(np.mean((A @ np.array([fb, d0]) - D) ** 2))), 2),
                         mape_pct=round(float(np.mean(np.abs(zp - Z) / Z) * 100), 2)))
    return pd.DataFrame(rows).sort_values("target").reset_index(drop=True)


def tbl_fb_fit(df):
    d = df[(df["task"].isin(["accuracy", "hard"])) & df["true_m"].notna()
           & df["d_full"].notna()].copy()
    if d.empty:
        return pd.DataFrame()
    d["true_m"] = d["true_m"].astype(float)
    d["fb_implied"] = d["d_full"] * d["true_m"] * 1000.0
    rows = []
    for (tg, tm), g in d.groupby(["target", "true_m"]):
        rows.append(dict(target=tg, true_m=tm, n=len(g),
                         d_med=round(float(g["d_full"].median()), 3),
                         d_std=round(float(g["d_full"].std()), 3),
                         fb_implied=round(float(g["fb_implied"].median()), 1)))
    out = pd.DataFrame(rows).sort_values(["target", "true_m"]).reset_index(drop=True)
    if out.empty:
        return out
    Z = d["true_m"].values.astype(float)
    D = d["d_full"].values.astype(float)
    A = np.stack([1.0 / (Z * 1000.0), np.ones_like(Z)], axis=1)
    (fb, d0), *_ = np.linalg.lstsq(A, D, rcond=None)
    off = -float(d0)
    zp = fb / (D + off) / 1000.0
    out.attrs["fb_fit"] = float(fb)
    out.attrs["offset_fit"] = off
    out.attrs["rms_px"] = float(np.sqrt(np.mean((A @ np.array([fb, d0]) - D) ** 2)))
    out.attrs["mape_pct"] = float(np.mean(np.abs(zp - Z) / Z) * 100)
    out.attrs["fb_old"] = float(d["fb_mm_px"].iloc[0])
    out.attrs["offset_old"] = float(d["disp_offset_px"].iloc[0]) if "disp_offset_px" in d else 0.0
    out["z_fit"] = [round(float(fb / (r["d_med"] + off) / 1000.0), 3) for _, r in out.iterrows()]
    out["err_pct"] = [round((r["z_fit"] - r["true_m"]) / r["true_m"] * 100, 1)
                      for _, r in out.iterrows()]
    return out


# ---------------------------------------------------------------------------
# 图与报告
# ---------------------------------------------------------------------------
def make_figures(acc, abl, rej, outdir: Path):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except Exception as e:
        print(f"[fig] matplotlib 不可用: {e}")
        return []
    made = []
    if not acc.empty:
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(9, 3.8))
        for tg, g in acc.groupby("target"):
            g = g[g["n_ok"] > 0]
            if g.empty:
                continue
            ax1.plot(g["true_m"], g["mean_z"], "o-", label=tg)
            ax2.plot(g["true_m"], g["mape_pct"], "s-", label=tg)
        lim = [0, float(acc["true_m"].max()) * 1.05]
        ax1.plot(lim, lim, "k--", lw=0.8, label="ideal")
        ax1.set_xlabel("True distance (m)"); ax1.set_ylabel("Measured distance (m)")
        ax1.set_title("(a) Measured vs true"); ax1.legend(fontsize=7); ax1.grid(alpha=.3)
        ax2.set_xlabel("True distance (m)"); ax2.set_ylabel("MAPE (%)")
        ax2.set_title("(b) Error by distance"); ax2.legend(fontsize=7); ax2.grid(alpha=.3)
        fig.tight_layout()
        p = outdir / "fig_accuracy.png"; fig.savefig(p, dpi=160); plt.close(fig)
        made.append(p)
    if not abl.empty:
        fig, ax = plt.subplots(figsize=(6.6, 4.0))
        for m, g in abl[abl["n_ok"] > 0].groupby("method"):
            g = g.sort_values("true_m")
            fail = float(g["fail_pct"].mean())
            ax.plot(g["true_m"], g["mae_mm"], "o-",
                    label=f"{m}  (reject {fail:.0f}%)" if fail > 1 else m,
                    alpha=1.0 if fail <= 50 else 0.55)
        ax.set_xlabel("True distance (m)"); ax.set_ylabel("MAE (mm)")
        ax.set_title("Same-frame ablation (legend = mean rejection rate)")
        ax.legend(fontsize=8); ax.grid(alpha=.3)
        fig.tight_layout()
        p = outdir / "fig_ablation.png"; fig.savefig(p, dpi=160); plt.close(fig)
        made.append(p)
    if not rej.empty and rej["p95_mm"].notna().any():
        fig, ax = plt.subplots(figsize=(5.6, 3.8))
        r = rej[rej["p95_mm"].notna() & (rej["min_valid"] > 0)].copy()
        for mm, g in r.groupby("max_mad"):
            g = g.sort_values("coverage")
            ax.plot(g["coverage"] * 100, g["p95_mm"], "o-", label=f"MAD<{mm}")
        base = rej[(rej["min_valid"] == 0) & rej["p95_mm"].notna()]
        if len(base):
            ax.axhline(float(base["p95_mm"].iloc[0]), color="k", ls="--", lw=0.8,
                       label="no rejection")
        ax.set_xlabel("Coverage (%)"); ax.set_ylabel("p95 error (mm)")
        ax.set_title("Reject-error trade-off"); ax.legend(fontsize=7); ax.grid(alpha=.3)
        fig.tight_layout()
        p = outdir / "fig_reject.png"; fig.savefig(p, dpi=160); plt.close(fig)
        made.append(p)
    return made


def md_table(df: pd.DataFrame, title: str) -> str:
    if df is None or df.empty:
        return f"### {title}\n（无数据）\n"
    cols = list(df.columns)
    if "target" in cols and df["target"].nunique() <= 1:
        cols = [c for c in cols if c != "target"]
    lines = [f"### {title}", "", "| " + " | ".join(cols) + " |",
             "|" + "|".join(["---"] * len(cols)) + "|"]
    for _, r in df.iterrows():
        lines.append("| " + " | ".join("" if pd.isna(r[c]) else str(r[c]) for c in cols) + " |")
    return "\n".join(lines) + "\n"


# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--session", action="append", default=[])
    ap.add_argument("--all", action="store_true")
    ap.add_argument("--box", default="auto", choices=["auto", "center", "yolo"])
    ap.add_argument("--fb", type=float, default=None)
    ap.add_argument("--offset", type=float, default=None)
    ap.add_argument("--no-cache", action="store_true")
    ap.add_argument("--max-frames", type=int, default=None)
    ap.add_argument("--write-scale", action="store_true")
    args = ap.parse_args()

    sessions = list_sessions(args.all, args.session)
    if not sessions:
        print("没有找到会话。先跑 e_all_record.py，或用 --session 指定目录。")
        return 1
    info = calib_fb(CALIB)
    scale = load_scale(CALIB)
    fb = float(args.fb) if args.fb else float(scale.fb_mm_px)
    off = float(args.offset) if args.offset is not None else float(scale.disp_offset_px or 0.0)
    print("=" * 78)
    print(f"会话 {len(sessions)} 个: " + ", ".join(s.name for s in sessions))
    print(f"fB = {fb:.1f} mm·px   视差零偏 = {off:+.2f} px   (当前口径: {scale.summary()})")
    print(f"标定: fB_stored={info['fb_stored']:.0f}  fB_rectified={info['fb_rectified']:.0f}")
    print("=" * 78)

    df = extract_features(sessions, args.box, fb, disp_offset_px=off,
                          cache=not args.no_cache, max_frames=args.max_frames)
    if df.empty:
        print("没有可分析的帧")
        return 1

    acc = tbl_accuracy(df, "z_full", fb)
    acc_roi = tbl_accuracy(df, "z_roi", fb)
    acc_v2 = tbl_accuracy(df, "z_roi2", fb)
    paths = tbl_path_compare(df, fb)
    abl = tbl_ablation(df, fb)
    stab = tbl_stability(df)
    rej = tbl_reject(df)
    fbf = tbl_fb_fit(df)
    fbt = fit_by_target(df)

    outdir = sessions[0] if len(sessions) == 1 else SESSIONS
    for name, t in [("table1_accuracy", acc), ("table1b_accuracy_roi", acc_roi),
                    ("table1c_accuracy_roi_v2", acc_v2), ("table_path_compare", paths),
                    ("table2_ablation", abl), ("table3_stability", stab),
                    ("table4_reject", rej), ("e0_fb_fit", fbf),
                    ("e0_fb_fit_by_target", fbt)]:
        if t is not None and not t.empty:
            t.to_csv(outdir / f"{name}.csv", index=False, encoding="utf-8")

    figs = make_figures(acc, abl, rej, outdir)

    if not fbt.empty:
        print("\n[E0 分目标] 尺度基准取平面目标（板），人体用于交叉验证")
        print(fbt.to_string(index=False))
    if not fbf.empty:
        print(f"\n[E0] 合并拟合（仅参考）: fB={fbf.attrs['fb_fit']:.0f} mm·px  "
              f"零偏={fbf.attrs['offset_fit']:+.2f} px  "
              f"(rms {fbf.attrs['rms_px']:.2f} px, MAPE {fbf.attrs['mape_pct']:.2f}%)")
    if not acc.empty:
        print("\n[Table 1] 测距精度（全帧路径）")
        print(acc.to_string(index=False))
    if not acc_roi.empty:
        print("\n[Table 1b] 测距精度（旧 ROI 路径 320 画布）")
        print(acc_roi.to_string(index=False))
    if not acc_v2.empty:
        print("\n[Table 1c] 测距精度（新 ROI v2：原生裁剪 + 左扩 + 自适应视差）")
        print(acc_v2.to_string(index=False))
    if not paths.empty:
        print("\n[路径对比] 精度 vs 计算当量（work = 像素 × 视差范围，全帧=1.0）")
        print(paths.to_string(index=False))
        if paths.attrs.get("ratio_p95") is not None:
            print(f"     v2 ROI：work/p95 = {paths.attrs['ratio_p95']:.4f}  "
                  f"max_disp 中位 = {paths.attrs['maxdisp_med']:.0f}  "
                  f"窗口中位 = {paths.attrs['win_med'][0]:.0f}x{paths.attrs['win_med'][1]:.0f}")
    if not abl.empty:
        print("\n[Table 2] 同帧消融")
        print(abl.to_string(index=False))
    if not stab.empty:
        print("\n[Table 3] 时序稳定性")
        print(stab.to_string(index=False))
    if not rej.empty:
        print("\n[Table 4] 拒识-误差曲线（节选）")
        print(rej.sort_values("coverage").to_string(index=False))
    for p in figs:
        print(f"[fig] {p}")

    parts = ["# E-ALL 分析报告", "",
             f"- 生成时间: {datetime.now():%Y-%m-%d %H:%M}",
             f"- 会话: {', '.join(s.name for s in sessions)}",
             f"- 帧数: {len(df)}", f"- fB 使用: {fb:.1f} mm·px  零偏 {off:+.2f} px ({scale.source})",
             f"- 标定: `{CALIB.name}`，md5 见各 session.json", ""]
    parts += [md_table(fbt, "E0 fB 分目标拟合（尺度基准取平面目标）")]
    parts += [md_table(fbf, "E0 fB 合并拟合（仅参考）")]
    parts += [md_table(acc, "Table 1 测距精度（全帧路径）")]
    parts += [md_table(acc_roi, "Table 1b 测距精度（旧 ROI 路径）")]
    parts += [md_table(acc_v2, "Table 1c 测距精度（新 ROI v2）")]
    parts += [md_table(paths, "路径对比：精度 vs 计算当量")]
    parts += [md_table(abl, "Table 2 同帧消融")]
    parts += [md_table(stab, "Table 3 时序稳定性")]
    parts += [md_table(rej, "Table 4 拒识-误差曲线")]
    if figs:
        parts += ["### 图", ""] + [f"- `{p.name}`" for p in figs]
    (outdir / "summary.md").write_text("\n".join(parts), encoding="utf-8")
    print(f"\n[out] {outdir / 'summary.md'}")

    if args.write_scale and not fbf.empty:
        p = save_fit(fbf.attrs["fb_fit"], distances_m=sorted(fbf["true_m"].unique()),
                     n_per_dist={str(r["true_m"]): int(r["n"]) for _, r in fbf.iterrows()},
                     rms_pct=fbf.attrs["mape_pct"],
                     calib_fb_value=fbf.attrs["fb_old"],
                     disp_offset_px=fbf.attrs["offset_fit"],
                     note=f"joint fit from {', '.join(s.name for s in sessions)}")
        print(f"[scale] 已写入 {p}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
