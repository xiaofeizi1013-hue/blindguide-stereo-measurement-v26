"""Run portable numerical and figure checks in an isolated copy of supplied inputs."""
from pathlib import Path
import argparse,json,shutil,subprocess,sys,time
R=Path(__file__).resolve().parent
ap=argparse.ArgumentParser(description=__doc__)
ap.add_argument('--check',action='store_true');ap.add_argument('--figures',action='store_true');ap.add_argument('--tables',action='store_true');ap.add_argument('--out',default='reproduced')
args=ap.parse_args();args.check=args.check or not(args.figures or args.tables)
out=(R/args.out).resolve() if not Path(args.out).is_absolute() else Path(args.out).resolve()
assert out!=R and out not in R.parents,'Choose a separate output directory.'
assert not any(out==R/name or R/name in out.parents for name in ['analysis','representatives','authoring','audit','figures']),'Keep outputs outside input directories.'
out.mkdir(parents=True,exist_ok=True);work=out/'work';work.mkdir(exist_ok=True)
for name in ['analysis','representatives']:
    shutil.copytree(R/name,work/name,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','qa','reset_image_qa','anchor_image_qa'))
shutil.copytree(R/'reproducibility/roi',work/'reproducibility/roi',dirs_exist_ok=True)
(work/'audit').mkdir(exist_ok=True);shutil.copy2(R/'audit/v23_derived_input_hashes.json',work/'audit/v23_derived_input_hashes.json')
(work/'figures').mkdir(exist_ok=True)
scripts=['verify_packet.py','verify_reset.py','verify_reports_anchors.py','verify_paired.py','verify_roi_inputs.py','analyze_pairs.py','analyze_reports_anchors.py','reproduce_tables.py','figure_evidence.py','figure_metrics.py','figure_reset.py','figures_reports_anchors.py']
for name in scripts:shutil.copy2(R/name,work/name)
commands=['analyze_pairs.py','analyze_reports_anchors.py']
if args.check:commands+=['verify_packet.py','verify_reset.py','verify_reports_anchors.py','verify_paired.py','verify_roi_inputs.py']
if args.tables:commands+=['reproduce_tables.py']
if args.figures:commands+=['figure_evidence.py','figure_metrics.py','figure_reset.py','figures_reports_anchors.py']
records=[]
for name in commands:
    before=time.monotonic();p=subprocess.run([sys.executable,str(work/name)],cwd=work,capture_output=True,text=True,encoding='utf8',errors='replace')
    (out/(name+'.log')).write_text(p.stdout+'\n'+p.stderr,encoding='utf8')
    records.append(dict(script=name,exit_code=p.returncode,seconds=round(time.monotonic()-before,2)))
    if p.returncode:print(p.stdout[-1000:]+p.stderr[-2000:]);raise SystemExit(p.returncode)
    print(name,'passed',flush=True)
if args.tables:shutil.copytree(work/'tables',out/'tables',dirs_exist_ok=True)
if args.figures:shutil.copytree(work/'figures',out/'figures',dirs_exist_ok=True)
(out/'reproduction_result.json').write_text(json.dumps(dict(status='passed',commands=records,isolated_inputs=True,raw_images_required=False,cuda_required=False),indent=2),encoding='utf8')
print('Reproduction complete:',out)
