from pathlib import Path
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent;A=R/'analysis';F=R/'figures'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':13,'axes.spines.top':False,'axes.spines.right':False})
x=pd.read_csv(A/'anchor_frame_inventory.csv');x=x[x.session.str.startswith('S1_')]
fig,axes=plt.subplots(1,2,figsize=(10.6,4.0),layout='constrained')
for z,ax in zip([1.,4.],axes):
 a=x[(x.true_m==z)&(x.backend=='libSGM')].sort_values('seq')
 b=x[(x.true_m==z)&(x.backend=='OpenCV_SGBM')].sort_values('seq');index=np.arange(1,31)
 ax.plot(index,a.d,'o-',color='#176b9b',markersize=3.5,linewidth=1,label='libSGM')
 good=b.default_score_pass.to_numpy()
 ax.scatter(index[good],b.d.to_numpy()[good],s=22,color='#c45029',label='OpenCV: score pass',zorder=3)
 ax.scatter(index[~good],b.d.to_numpy()[~good],s=26,facecolors='none',edgecolors='#c45029',label='OpenCV: score fail',zorder=3)
 med=float(b.d.median());ax.axhline(med,color='#775a48',linestyle='--',linewidth=1)
 ax.set(xlabel='Frame within anchor burst',ylabel='Region median disparity (px)',title=f'({"a" if z==1 else "b"}) S1 at {z:g} m')
 ax.grid(alpha=.18)
 if z==1:
  ax.annotate('Group median\n22.5625 px',(18,med),xytext=(16,13),fontsize=11,
   arrowprops=dict(arrowstyle='->',color='#555555',lw=.8));ax.set_ylim(-1,49)
  ax.legend(frameon=False,loc='upper left',bbox_to_anchor=(.02,.88),fontsize=10)
 else:ax.set_ylim(9.05,9.78)
for ext in ['png','svg']:fig.savefig(F/f'figS1_anchor_distributions.{ext}',dpi=240,facecolor='white')
plt.close(fig)
s=pd.read_csv(A/'mad_threshold_scan.csv');s=s[(s.backend=='OpenCV_SGBM')&(s.protocol=='two_anchor_heldout')]
fig,axes=plt.subplots(1,2,figsize=(10.6,4.0),layout='constrained')
for prefix,label,color in [('S1_','OpenCV / S1','#176b9b'),('S7_','OpenCV / S7','#c45029'),('S10_','OpenCV / S10','#27816c')]:
 g=s[s.session.str.startswith(prefix)].sort_values('threshold_px');g=g[g.reported_n>0]
 assert (g.reported_MAPE>0).all()
 axes[0].plot(g.reported_coverage_pct,g.reported_MAPE,'o-',color=color,markersize=3,linewidth=1.2,label=label)
 axes[1].plot(g.reported_coverage_pct,g.gt500_given_report_pct,'o-',color=color,markersize=3,linewidth=1.2)
 default=g[g.threshold_px==3.].iloc[0]
 for ax,key in [(axes[0],'reported_MAPE'),(axes[1],'gt500_given_report_pct')]:
  ax.scatter([default.reported_coverage_pct],[default[key]],s=75,facecolors='none',edgecolors=color,linewidth=1.8,zorder=4)
axes[0].set(xlabel='Reports / attempted frames (%)',ylabel='Reported MAPE (%)',title='(a) Conditional average error',yscale='log',xlim=(0,101))
axes[1].set(xlabel='Reports / attempted frames (%)',ylabel='Reported errors >500 mm (%)',title='(b) Exceedances among reports',xlim=(0,101),ylim=(-2,102))
axes[0].legend(frameon=False,fontsize=10,loc='lower left')
for ax in axes:ax.grid(alpha=.18)
for ext in ['png','svg']:fig.savefig(F/f'figS2_reported_risk_coverage.{ext}',dpi=240,facecolor='white')
print('Saved descriptive anchor and fixed-model MAD sweep figures')
