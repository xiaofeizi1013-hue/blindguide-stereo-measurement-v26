"""Report-conditioned error, anchor distributions and descriptive fixed-threshold sweeps."""
from pathlib import Path
import json
import numpy as np,pandas as pd
R=Path(__file__).resolve().parent;A=R/'analysis'
p=pd.read_csv(A/'backend_predictions.csv');features=pd.read_csv(A/'backend_features.csv')
keys=['backend','session','seq'];assert not features.duplicated(keys).any()
p=p.merge(features[keys+['computable','n','valid_fraction']],on=keys,how='left',validate='many_to_one')
assert p.computable.notna().all()
assert np.array_equal(p.gate_accept.to_numpy(),(p.range_valid&p.score_pass).to_numpy())
assert np.array_equal(p.score_pass.to_numpy(),((p.MAD<=3)&(p.n>=10)).to_numpy())
def errstats(g,mask,prefix):
 e=abs(g.loc[mask,'error_mm'].to_numpy());z=g.loc[mask,'true_m'].to_numpy()*1000
 return {prefix+'n':len(e),prefix+'MAPE':float(np.mean(e/z)*100) if len(e) else np.nan,
   prefix+'MAE_mm':float(np.mean(e)) if len(e) else np.nan,
   prefix+'p95_mm':float(np.percentile(e,95)) if len(e) else np.nan,
   prefix+'max_mm':float(np.max(e)) if len(e) else np.nan}
def summarize(g,accept):
 v=g.range_valid;out=dict(attempted_n=len(g),invalid_range_n=int((~v).sum()),
  reported_coverage_pct=float(np.mean(accept)*100),**errstats(g,v,'valid_'),**errstats(g,accept,'reported_'))
 for t in [250,500,1000]:
  bad=v&(abs(g.error_mm)>t);b=int(bad.sum());a=int((bad&accept).sum());r=int(accept.sum())
  out.update({f'valid_gt{t}_n':b,f'reported_gt{t}_n':a,
    f'pass_given_gt{t}_pct':100*a/b if b else np.nan,
    f'gt{t}_given_report_pct':100*a/r if r else np.nan})
 return out
rows=[];sweeps=[]
thresholds=[0,.25,.5,.75,1.,1.5,2.,3.,4.,6.,8.,12.,16.,24.,32.,np.inf]
for (backend,session,protocol),g in p.groupby(['backend','session','protocol'],sort=False):
 base=dict(backend=backend,session=session,protocol=protocol,K=float(g.K.iloc[0]),d0=float(g.d0.iloc[0]))
 rows.append(dict(**base,**summarize(g,g.gate_accept)))
 for theta in thresholds:
  ac=g.range_valid&g.computable&(g.n>=10)&(g.MAD<=theta)
  sweeps.append(dict(**base,threshold_px=theta,**summarize(g,ac)))
reports=pd.DataFrame(rows);reports.to_csv(A/'reported_backend_metrics.csv',index=False)
pd.DataFrame(sweeps).to_csv(A/'mad_threshold_scan.csv',index=False)
distance_rows=[]
for (be,se,pr,z),g in p.groupby(['backend','session','protocol','true_m'],sort=False):
 distance_rows.append(dict(backend=be,session=se,protocol=pr,distance_m=z,**summarize(g,g.gate_accept)))
pd.DataFrame(distance_rows).to_csv(A/'reported_backend_per_distance.csv',index=False)
anchors=features[features.true_m.isin([1.,4.])].copy()
anchors['default_score_pass']=(anchors.mad<=3)&(anchors.n>=10)
anchors.to_csv(A/'anchor_frame_inventory.csv',index=False)
summ=[]
for (be,se,z),g in anchors.groupby(['backend','session','true_m'],sort=False):
 d=g.d.to_numpy();mad=g.mad.to_numpy()
 summ.append(dict(backend=be,session=se,anchor_m=z,n=len(g),
   d_min=float(d.min()),d_p10=float(np.percentile(d,10)),d_p25=float(np.percentile(d,25)),
   d_median=float(np.median(d)),d_p75=float(np.percentile(d,75)),d_p90=float(np.percentile(d,90)),d_max=float(d.max()),
   frame_MAD_min=float(mad.min()),frame_MAD_median=float(np.median(mad)),frame_MAD_max=float(mad.max()),
   score_pass_n=int(g.default_score_pass.sum()),computable_n=int(g.computable.sum())))
summary=pd.DataFrame(summ);summary.to_csv(A/'anchor_disparity_summary.csv',index=False)
effective=[];bm=pd.read_csv(A/'backend_metrics.csv')
for (be,se),g in anchors.groupby(['backend','session'],sort=False):
 a=g.groupby('true_m').d.median();K=float((a.loc[1.]-a.loc[4.])/(.001-.00025));d0=float(a.loc[1.]-K*.001)
 old=bm[(bm.backend==be)&(bm.session==se)&(bm.protocol=='two_anchor_heldout')].iloc[0]
 assert np.isclose(K,old.K) and np.isclose(d0,old.d0)
 effective.append(dict(backend=be,session=se,anchor1_median_px=float(a.loc[1.]),anchor4_median_px=float(a.loc[4.]),
    K=K,d0=d0,geometric_K=45870.,K_fraction_geometric=K/45870.,
    fit_rule='Median of all computable frames at each anchor; no MAD-based anchor exclusion'))
pd.DataFrame(effective).to_csv(A/'anchor_effective_parameters.csv',index=False)
g=anchors[(anchors.backend=='OpenCV_SGBM')&anchors.session.str.startswith('S1_')&(anchors.true_m==1.)]
sd=np.sort(g.d.to_numpy());gap_index=int(np.argmax(np.diff(sd)));cut=float((sd[gap_index]+sd[gap_index+1])/2)
branch=[]
for name,q in [('lower',g[g.d<cut]),('upper',g[g.d>cut])]:
 branch.append(dict(branch=name,n=len(q),d_min=float(q.d.min()),d_max=float(q.d.max()),
  default_score_pass_n=int(q.default_score_pass.sum())))
branch_record=dict(rule='Descriptive split at the largest adjacent gap; no frame excluded or calibration replaced',
 largest_gap_px=float(np.diff(sd)[gap_index]),gap_midpoint_px=cut,group_median_px=float(np.median(sd)),
 group_median_is_observed_value=bool(np.any(sd==np.median(sd))),branches=branch)
(A/'S1_OpenCV_anchor_branch_diagnostic.json').write_text(json.dumps(branch_record,indent=2),encoding='utf8')
rp=pd.read_csv(A/'reset_per_distance.csv');changes=[]
for z,g in rp.groupby('distance_m'):
 f=g[g.protocol=='frozen_C0'].iloc[0];r=g[g.protocol=='refit_C1'].iloc[0]
 if z in [1.,4.]:continue
 changes.append(dict(distance_m=z,frozen_MAPE=f.MAPE,refit_MAPE=r.MAPE,delta_percentage_points=r.MAPE-f.MAPE))
pd.DataFrame(changes).to_csv(A/'C1_refit_local_changes.csv',index=False)
focus=reports[(reports.backend=='OpenCV_SGBM')&reports.session.str.startswith('S7_')&(reports.protocol=='two_anchor_heldout')].iloc[0]
assert int(focus.reported_n)==208 and int(focus.reported_gt500_n)==5 and int(focus.valid_gt500_n)==37
assert np.isclose(focus.reported_MAPE,2.91,atol=.005) and np.isclose(focus.reported_p95_mm,88.2,atol=.05)
counts=dict(source_pairs=len(features)//2,source_backend_rows=len(features),protocol_rows=len(rows),
 scan_rows=len(sweeps),anchor_distribution_rows=len(summary),anchor_backend_observations=len(anchors),
 minimum_n_among_computable=int(features.loc[features.computable,'n'].min()),
 n_computable_failing_redundant_n10=int(((features.n<10)&features.computable).sum()),
 threshold_choice='Inherited 3 px remains unchanged. Offline sweeps are descriptive and are not used to optimize the reporting threshold.',
 anchor_policy='All computable anchor medians remain in calibration; failures are retained.',
 locally_worse_C1_distances=[float(x['distance_m']) for x in changes if x['delta_percentage_points']>0])
(A/'report_anchor_audit.json').write_text(json.dumps(counts,indent=2),encoding='utf8')
print('Two-anchor backend results:')
print(reports[reports.protocol=='two_anchor_heldout'][['backend','session','valid_n','reported_n','valid_MAPE','reported_MAPE','reported_MAE_mm','reported_p95_mm','reported_max_mm','valid_gt500_n','reported_gt500_n','gt500_given_report_pct']].to_string(index=False))
print('S1 anchor distributions:')
print(summary[summary.session.str.startswith('S1_')].to_string(index=False))
print(json.dumps(branch_record,indent=2))
print(json.dumps(counts,indent=2))
