from pathlib import Path
import pandas as pd,numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

R=Path(__file__).resolve().parent
x=pd.read_csv(R/'analysis/reset_predictions.csv')
x=x[x.session.str.startswith('C1_')]
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False})
fig,ax=plt.subplots(1,2,figsize=(11.7,3.9),layout='constrained')
colors=['#c45229','#16699b']
for protocol,label,color in [('C0_frozen_to_C1','Frozen C0',colors[0]),('C1_two_anchor_refit','Refit C1',colors[1])]:
 g=x[x.protocol==protocol]
 agg=g.groupby('true_m').signed_error_mm.agg(['mean','min','max'])
 y=agg['mean'].to_numpy();err=np.vstack([y-agg['min'].to_numpy(),agg['max'].to_numpy()-y])
 ax[0].errorbar(agg.index,y,yerr=np.maximum(err,0),fmt='o-',markersize=4,capsize=2.5,color=color,label=label,linewidth=1.4)
 e=np.sort(g[~g.true_m.isin([1.,4.])].abs_error_mm.to_numpy())
 ax[1].step(np.r_[0,e,250],np.r_[0,np.arange(1,len(e)+1)/len(e),1.0],where='post',color=color,label=label,linewidth=1.7)
for z in [1.,4.]:ax[0].axvspan(z-.10,z+.10,color='#777777',alpha=.15,zorder=0)
ax[0].axhline(0,color='#444444',linewidth=.7)
ax[0].set(xlabel='Nominal board distance (m)',ylabel='Signed range error (mm)',title='(a) C1 distance groups (30 frames each)')
ax[0].legend(frameon=False,loc='upper left');ax[0].set_xticks(np.arange(.5,5.1,.5));ax[0].grid(alpha=.17)
ax[1].set(xlabel='Absolute range error (mm)',ylabel='Empirical cumulative fraction',title='(b) Common eight test distances (n=240)',xlim=(0,250),ylim=(0,1.03))
ax[1].legend(frameon=False,loc='lower right');ax[1].grid(alpha=.17)
fig.savefig(R/'figures/fig5.png',dpi=260,facecolor='white')
fig.savefig(R/'figures/fig5.svg',facecolor='white')
print('Saved C1 plot from frame predictions without CI or pooled reset statistics')
